<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:55
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/find_people.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c63016275_04186475',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ad87b4d0ff20b58cc826f9ec302049b34e9a7301' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/find_people.svg',
      1 => 1685358563,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c63016275_04186475 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg id="OBJECT" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m30.27 26.73-5.49-5.48a13 13 0 1 0 -3.53 3.54l5.48 5.48a2.5 2.5 0 0 0 3.54-3.54zm-27.27-12.73a11 11 0 1 1 11 11 11 11 0 0 1 -11-11zm25.85 14.85a.48.48 0 0 1 -.7 0l-5.33-5.32c.24-.23.48-.47.7-.71l5.33 5.33a.49.49 0 0 1 .15.35.47.47 0 0 1 -.15.35z"/><path d="m17.4 13.08a4 4 0 1 0 -6.8 0 6 6 0 0 0 -2.6 4.92 3 3 0 0 0 3 3h6a3 3 0 0 0 3-3 6 6 0 0 0 -2.6-4.92zm-3.4-4.08a2 2 0 1 1 -2 2 2 2 0 0 1 2-2zm3 10h-6a1 1 0 0 1 -1-1 4 4 0 0 1 2.1-3.5 3.86 3.86 0 0 0 3.8 0 4 4 0 0 1 2.1 3.5 1 1 0 0 1 -1 1z"/></svg><?php }
}
