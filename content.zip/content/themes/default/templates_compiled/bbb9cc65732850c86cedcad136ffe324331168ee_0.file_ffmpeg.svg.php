<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/ffmpeg.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135b0f082_93474149',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bbb9cc65732850c86cedcad136ffe324331168ee' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/ffmpeg.svg',
      1 => 1657116565,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135b0f082_93474149 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0" encoding="UTF-8" standalone="no"<?php echo '?>'; ?>

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="64"
   height="64"
   viewBox="0 0 63.999999 64.000001"
   version="1.1"
   id="svg2"
   inkscape:version="0.48.4 r9939"
   sodipodi:docname="FFmpeg_Logo_new.svg">
  <metadata
     id="metadata67">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1920"
     inkscape:window-height="1017"
     id="namedview65"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:zoom="4.3476779"
     inkscape:cx="24.034139"
     inkscape:cy="44.123162"
     inkscape:window-x="-8"
     inkscape:window-y="-8"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg2" />
  <defs
     id="defs4">
    <radialGradient
       id="a"
       gradientUnits="userSpaceOnUse"
       cy="442.72311"
       cx="-122.3936"
       gradientTransform="matrix(1,0,0,-1,134.4463,453.7334)"
       r="29.5804">
      <stop
         stop-color="#fff"
         offset="0"
         id="stop7" />
      <stop
         stop-color="#007808"
         offset="1"
         id="stop9" />
    </radialGradient>
  </defs>
  <g
     id="g11"
     transform="translate(1.3244995,2.7985005)">
    <polygon
       points="5.402,13.541 0.511,12.364 0.511,5.078 5.402,6.763 "
       id="polygon13"
       style="fill:#0b4819" />
    <polygon
       points="9.13,41.393 4.455,42.317 4.455,15.226 9.13,16.215 "
       id="polygon15"
       style="fill:#0b4819" />
    <polygon
       points="60.662,55.981 34.012,53.917 47.597,40.738 47.597,34.243 28.175,53.465 4.919,51.667 42.222,11.55 36.083,11.882 9.13,41.393 9.13,16.215 11.683,13.201 5.402,13.541 5.402,6.763 27.321,5.066 15.306,18.846 15.306,24.71 33.126,4.617 61.351,2.432 19.834,45.706 25.361,45.997 55.516,15.154 55.516,44.305 52.166,47.454 60.662,47.913 "
       id="polygon17"
       style="fill:#105c80" />
    <polygon
       points="9.13,16.215 4.455,15.226 7.159,11.971 11.683,13.201 "
       id="polygon19"
       style="fill:#0b4819" />
    <polygon
       points="11.004,24.358 11.004,18.039 15.306,18.846 15.306,24.71 "
       id="polygon21"
       style="fill:#084010" />
    <polygon
       points="21.714,47.346 15.82,47.006 19.834,45.706 25.361,45.997 "
       id="polygon23"
       style="fill:#0c541e" />
    <polygon
       points="11.004,18.039 23.808,3.106 27.321,5.066 15.306,18.846 "
       id="polygon25"
       style="fill:#1a5c34" />
    <polygon
       points="15.306,24.71 11.004,24.358 30.022,2.58 33.126,4.617 "
       id="polygon27"
       style="fill:#0b4819" />
    <polygon
       points="4.455,42.317 33.195,10.432 36.083,11.882 9.13,41.393 "
       id="polygon29"
       style="fill:#1a5c34" />
    <polygon
       points="4.919,51.667 0,53.344 39.798,10.042 42.222,11.55 "
       id="polygon31"
       style="fill:#0b4819" />
    <polygon
       points="24.721,55.437 45.597,34.677 47.597,34.243 28.175,53.465 "
       id="polygon33"
       style="fill:#1a5c34" />
    <polygon
       points="47.597,40.738 45.597,41.737 45.597,34.677 47.597,34.243 "
       id="polygon35"
       style="fill:#0b4819" />
    <polygon
       points="34.012,53.917 30.973,55.965 45.597,41.737 47.597,40.738 "
       id="polygon37"
       style="fill:#0b4819" />
    <polygon
       points="55.516,44.305 54.168,45.648 50.538,49.059 52.166,47.454 "
       id="polygon39"
       style="fill:#13802d" />
    <polygon
       points="25.361,45.997 21.714,47.346 54.168,13.9 55.516,15.154 "
       id="polygon41"
       style="fill:#0b4819" />
    <polygon
       points="54.168,45.648 54.168,13.9 55.516,15.154 55.516,44.305 "
       id="polygon43"
       style="fill:#084010" />
    <polygon
       points="59.759,58.403 59.759,49.604 60.662,47.913 60.662,55.981 "
       id="polygon45"
       style="fill:#084010" />
    <polygon
       points="15.82,47.006 60.507,0 61.351,2.432 19.834,45.706 "
       id="polygon47"
       style="fill:#1a5c34" />
    <polygon
       points="59.759,58.403 30.973,55.965 45.597,41.737 45.597,34.677 24.721,55.437 0,53.344 39.798,10.042 33.195,10.432 4.455,42.317 4.455,15.226 7.159,11.971 0.511,12.364 0.511,5.078 23.808,3.106 11.004,18.039 11.004,24.358 30.022,2.58 60.507,0 15.82,47.006 21.714,47.346 54.168,13.9 54.168,45.648 50.538,49.059 59.759,49.604 "
       id="polygon49"
       style="fill:url(#a)" />
  </g>
</svg>
<?php }
}
