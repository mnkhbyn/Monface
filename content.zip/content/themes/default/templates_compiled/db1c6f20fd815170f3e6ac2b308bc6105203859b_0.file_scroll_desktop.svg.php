<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:46:47
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/scroll_desktop.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8057923bb3_83405641',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'db1c6f20fd815170f3e6ac2b308bc6105203859b' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/scroll_desktop.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8057923bb3_83405641 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" fill-rule="evenodd" d="M480 381.477a9.013 9.013 0 0 1-9 9H41a9.013 9.013 0 0 1-9-9v-305a9.014 9.014 0 0 1 9-9h430a9.014 9.014 0 0 1 9 9zm-156.972 63.037H188.981l12.719-22.039h108.6l12.723 22.039zM471 35.48H41A41.041 41.041 0 0 0 0 76.478v305a41.041 41.041 0 0 0 41.006 41h123.743l-17.338 30.04a16 16 0 0 0 13.852 24h189.476a16 16 0 0 0 13.852-24l-17.338-30.04H471a41.047 41.047 0 0 0 41.006-41v-305A41.047 41.047 0 0 0 471 35.48z" data-original="#0291f7"></path></g></svg><?php }
}
