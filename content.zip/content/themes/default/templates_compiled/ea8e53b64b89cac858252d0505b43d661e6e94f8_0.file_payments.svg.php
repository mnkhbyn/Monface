<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/payments.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c66565d94_82017708',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ea8e53b64b89cac858252d0505b43d661e6e94f8' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/payments.svg',
      1 => 1685114243,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c66565d94_82017708 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M27 27H5a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h22a3 3 0 0 1 3 3v16a3 3 0 0 1-3 3zM4 15v9a1 1 0 0 0 1 1h22a1 1 0 0 0 1-1v-9zm0-2h24v-2H4zm0-4h24V8a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1zm21 14h-1a1 1 0 0 1 0-2h1a1 1 0 0 1 0 2zm-4 0h-1a1 1 0 0 1 0-2h1a1 1 0 0 1 0 2zm-8 0H7a1 1 0 0 1 0-2h6a1 1 0 0 1 0 2z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
