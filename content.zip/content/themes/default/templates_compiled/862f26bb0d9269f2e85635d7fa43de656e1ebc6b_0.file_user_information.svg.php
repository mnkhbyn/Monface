<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:18
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/user_information.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c7aed7372_04424945',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '862f26bb0d9269f2e85635d7fa43de656e1ebc6b' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/user_information.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c7aed7372_04424945 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M13.733 18.168h-3.466a3.019 3.019 0 0 1-2.658-1.595 2.875 2.875 0 0 1 .12-2.987A5.172 5.172 0 0 1 12 11.063a5.17 5.17 0 0 1 4.271 2.524 2.873 2.873 0 0 1 .12 2.986 3.019 3.019 0 0 1-2.658 1.595zM12 12.563a3.705 3.705 0 0 0-3.018 1.848 1.38 1.38 0 0 0-.053 1.451 1.503 1.503 0 0 0 1.338.806h3.466a1.503 1.503 0 0 0 1.338-.806 1.378 1.378 0 0 0-.053-1.45A3.704 3.704 0 0 0 12 12.563z" data-original="#7fbde7"></path><path fill="#5e72e4" d="M12 12.563a3.366 3.366 0 1 1 3.366-3.366A3.37 3.37 0 0 1 12 12.563zm0-5.231a1.866 1.866 0 1 0 1.866 1.865A1.868 1.868 0 0 0 12 7.332z" data-original="#7fbde7"></path><path fill="#5e72e4" d="M20 21.75h-3a.75.75 0 0 1 0-1.5h3A1.251 1.251 0 0 0 21.25 19V5A1.251 1.251 0 0 0 20 3.75H4A1.251 1.251 0 0 0 2.75 5v14A1.251 1.251 0 0 0 4 20.25h10a.75.75 0 0 1 0 1.5H4A2.753 2.753 0 0 1 1.25 19V5A2.753 2.753 0 0 1 4 2.25h16A2.753 2.753 0 0 1 22.75 5v14A2.753 2.753 0 0 1 20 21.75z" data-original="#232323" class=""></path></g></g></svg><?php }
}
