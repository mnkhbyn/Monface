<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:46:47
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/youtube_player.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8057799784_61760514',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3d5461344b12f0f6f1f64de356ca334a6d807afa' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/youtube_player.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8057799784_61760514 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" fill-rule="evenodd" d="M219.545 289.087V168.87l104.114 60.109zm144.112-73.96L211.551 127.3a16 16 0 0 0-24 13.858V316.8a16 16 0 0 0 24 13.859l152.106-87.819a16 16 0 0 0 0-27.711zM480 381.478v-305a9.014 9.014 0 0 0-9-9H41a9.014 9.014 0 0 0-9 9v305a9.018 9.018 0 0 0 9 9h430a9.018 9.018 0 0 0 9-9zm-156.984 63.037H188.984l12.716-22.038h108.6zM471 35.474H41A41.046 41.046 0 0 0 0 76.479v305a41.041 41.041 0 0 0 41 41h123.752l-17.345 30.039a16 16 0 0 0 13.852 24h189.482a16 16 0 0 0 13.852-24l-17.345-30.039H471a41.041 41.041 0 0 0 41-41v-305a41.046 41.046 0 0 0-41-41.005z" data-original="#6c27b3" class=""></path></g></svg><?php }
}
