<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:52
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/fluid.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c9cd47a77_18746924',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0832107710f2302e88de1c4c1a13eecaf7d27421' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/fluid.svg',
      1 => 1685451436,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c9cd47a77_18746924 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg id="svg10654" height="512" viewBox="0 0 6.3499999 6.3500002" width="512" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg"><g id="layer1" transform="translate(0 -290.65)"><path id="path9475" d="m.52401501 290.90991a.26460982.26460982 0 0 0 -.2594157.26975v5.29064a.2646485.2646485 0 0 0 .52916664 0v-5.29064a.26460982.26460982 0 0 0 -.26975094-.26975zm5.29321699 0a.26460982.26460982 0 0 0 -.2619994.26975v5.29064a.2648417.2648417 0 0 0 .5296834 0v-5.29064a.26460982.26460982 0 0 0 -.267684-.26975zm-1.8066081 1.89859a.26460982.26460982 0 0 0 -.1834512.45527l.2966227.29663h-1.8985924l.2971396-.29663a.26460982.26460982 0 0 0 -.1917195-.4532.26460982.26460982 0 0 0 -.1813843.0801l-.7482748.74776a.26460982.26460982 0 0 0 0 .3731l.7482748.74828a.26460982.26460982 0 1 0 .3731038-.37311l-.2961061-.29714h1.8965252l-.295589.29714a.26460982.26460982 0 1 0 .3746539.37311l.7482748-.74828a.26460982.26460982 0 0 0 0-.3731l-.7482748-.74776a.26460982.26460982 0 0 0 -.1912027-.0822z" font-variant-ligatures="normal" font-variant-position="normal" font-variant-caps="normal" font-variant-numeric="normal" font-variant-alternates="normal" font-feature-settings="normal" text-indent="0" text-align="start" text-decoration-line="none" text-decoration-style="solid" text-decoration-color="rgb(0,0,0)" text-transform="none" text-orientation="mixed" white-space="normal" shape-padding="0" isolation="auto" mix-blend-mode="normal" solid-color="rgb(0,0,0)" solid-opacity="1" vector-effect="none"/></g></svg><?php }
}
