<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/digitalocean.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135cea1d2_22968529',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4306bdbf94d4c686daa3cb3b4a5279d6b74df614' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/digitalocean.svg',
      1 => 1638112703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135cea1d2_22968529 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg fill="#0080ff" height="64" viewBox="65.2 173.5 32 32" width="64" xmlns="http://www.w3.org/2000/svg"><path d="m81.202 205.5v-6.2c6.568 0 11.666-6.5 9.144-13.418a9.27 9.27 0 0 0 -5.533-5.531c-6.912-2.502-13.425 2.575-13.425 9.14h-6.188c0-10.463 10.124-18.622 21.1-15.195 4.8 1.505 8.618 5.313 10.105 10.1 3.43 10.99-4.717 21.107-15.203 21.107z"/><path d="m75.05 199.317v-6.165h6.168v6.165zm-4.753 4.75v-4.75h4.753v4.75zm0-4.75h-3.973v-3.97h3.973z"/></svg><?php }
}
