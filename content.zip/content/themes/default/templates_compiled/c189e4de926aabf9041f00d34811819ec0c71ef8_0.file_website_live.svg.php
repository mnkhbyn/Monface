<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/website_live.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d444c55_36981720',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c189e4de926aabf9041f00d34811819ec0c71ef8' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/website_live.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d444c55_36981720 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#7fbde7" d="M12 22a1 1 0 0 1-1-1v-5a1 1 0 0 1 2 0v5a1 1 0 0 1-1 1z" data-original="#7fbde7"></path><circle cx="12" cy="14" r="2.5" fill="#7fbde7" data-original="#7fbde7"></circle><g fill="#232323"><path d="M18 18.52a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42A7.5 7.5 0 1 0 4.5 11.5a7.44 7.44 0 0 0 2.21 5.31 1 1 0 1 1-1.42 1.42 9.5 9.5 0 1 1 13.42 0 1 1 0 0 1-.71.29z" fill="#5e72e4" data-original="#232323" class=""></path><path d="M16.59 15a1.09 1.09 0 0 1-.39-.08 1 1 0 0 1-.53-1.31A4.11 4.11 0 0 0 16 12a4 4 0 0 0-8 0 4.11 4.11 0 0 0 .33 1.61 1 1 0 1 1-1.84.78A6.12 6.12 0 0 1 6 12a6 6 0 0 1 12 0 6.16 6.16 0 0 1-.49 2.39 1 1 0 0 1-.92.61z" fill="#5e72e4" data-original="#232323" class=""></path></g></g></g></svg><?php }
}
