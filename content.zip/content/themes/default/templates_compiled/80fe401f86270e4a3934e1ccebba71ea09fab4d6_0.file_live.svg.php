<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:21
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/live.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e812d712012_06020158',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '80fe401f86270e4a3934e1ccebba71ea09fab4d6' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/live.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e812d712012_06020158 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#3cacb6" d="M16 18.4c-2.978 0-5.4-2.423-5.4-5.4s2.423-5.4 5.4-5.4 5.4 2.423 5.4 5.4-2.423 5.4-5.4 5.4zm0-8.801c-1.875 0-3.4 1.525-3.4 3.4s1.525 3.4 3.4 3.4 3.4-1.525 3.4-3.4-1.525-3.4-3.4-3.4z" data-original="#3cacb6"></path><path fill="#5e72e4" d="M26.9 13c0-6.011-4.89-10.9-10.9-10.9S5.1 6.989 5.1 13c0 4.89 3.236 9.037 7.68 10.414L11.276 28h-1.275a1 1 0 1 0 0 2h12a1 1 0 1 0 0-2h-1.276l-1.504-4.586c4.444-1.377 7.68-5.524 7.68-10.414zM13.379 28l1.37-4.177c.411.047.827.077 1.25.077s.839-.03 1.249-.077L18.618 28h-5.24zM7.1 13c0-4.907 3.993-8.9 8.9-8.9s8.9 3.993 8.9 8.9-3.993 8.9-8.9 8.9-8.9-3.993-8.9-8.9z" data-original="#06474d" class=""></path></g></svg><?php }
}
