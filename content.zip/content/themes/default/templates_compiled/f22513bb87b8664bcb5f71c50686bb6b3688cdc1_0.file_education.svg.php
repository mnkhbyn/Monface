<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/education.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80ced4f356_24418783',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f22513bb87b8664bcb5f71c50686bb6b3688cdc1' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/education.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80ced4f356_24418783 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512.049 512.049" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m507.655 351.422-39.661-39.662V175.716l25.893-9.335a14.998 14.998 0 0 0 .02-28.215l-236.9-85.794a15.001 15.001 0 0 0-10.215 0L9.893 138.166a15.002 15.002 0 0 0-.104 28.17l87.429 32.387v98.856c0 3.068.94 6.063 2.695 8.579.965 1.384 10.106 13.867 33.51 25.647 29.567 14.884 68.347 22.431 115.261 22.431 46.88 0 85.856-7.531 115.845-22.386 23.635-11.707 33.08-24.06 34.08-25.429a15.002 15.002 0 0 0 2.881-8.84v-97.89l36.505-13.161v125.23l-39.662 39.662a15 15 0 0 0 0 21.212l39.662 39.661v33.277c0 8.284 6.716 15 15 15s15-6.716 15-15v-33.277l39.661-39.661c5.858-5.856 5.858-15.355-.001-21.212zM251.9 82.429l192.761 69.809-195.906 70.629-190.144-70.438zm119.589 209.172c-51.279 46.142-203.657 40.851-244.271.15v-81.914l116.255 43.066c1.845.292 3.587 1.883 10.298.046l117.719-42.44v81.092zm81.505 93.269-22.843-22.842 22.843-22.843 22.842 22.843z" fill="#5e72e4" data-original="#000000"></path></g></svg><?php }
}
