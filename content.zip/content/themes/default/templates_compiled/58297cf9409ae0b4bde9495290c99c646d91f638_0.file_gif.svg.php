<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:56
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/gif.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c647debb6_31319152',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '58297cf9409ae0b4bde9495290c99c646d91f638' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/gif.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c647debb6_31319152 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 500 500" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#9653fe"><path d="M151.19 293.821h11.456v11.456H151.19zM187.667 286.33h7.592c-.02 1.576-.33 2.954-.922 4.098-.603 1.164-1.435 2.027-2.545 2.637-1.12.616-2.461.928-3.987.928-1.565 0-2.949-.29-4.115-.863-1.144-.562-2.001-1.339-2.619-2.375-.616-1.034-.928-2.255-.928-3.63v-14.806c0-1.602.316-3.026.94-4.234.618-1.194 1.461-2.089 2.58-2.733 1.117-.645 2.44-.971 3.935-.971 1.024 0 2.027.181 2.978.539a7.08 7.08 0 0 1 2.451 1.543 5.597 5.597 0 0 1 1.455 2.336l.225.69h12.162l-.241-1.198c-.626-3.103-1.842-5.874-3.615-8.236a18.289 18.289 0 0 0-6.695-5.529c-2.658-1.292-5.592-1.947-8.72-1.947-3.793 0-7.186.827-10.085 2.458-2.917 1.642-5.203 3.988-6.794 6.977-1.578 2.963-2.378 6.43-2.378 10.305v14.806c0 3.682.817 6.973 2.428 9.78 1.618 2.826 3.937 5.04 6.892 6.585 2.927 1.53 6.34 2.305 10.144 2.305 3.792 0 7.185-.827 10.085-2.458 2.918-1.641 5.204-3.995 6.795-6.994 1.577-2.976 2.377-6.448 2.377-10.322v-10.802h-19.394v11.111zM216.38 253.097h11.801v52.181H216.38zM238.535 305.277h11.456v-19.913h19.706v-11.111h-19.706v-10.045h23.503v-11.111h-34.96z" fill="#5e72e4" data-original="#9653fe"></path></g><path fill="#5e72e4" d="m410.94 164.563-84.946-84.946H135.83V201.01h22v-99.393h152.607v79.574h78.502v113.566h22zm-78.502-47.39 42.017 42.018h-42.017z" data-original="#171944" class=""></path><path fill="#5e72e4" d="M388.94 318.876h22v32.986h-22z" data-original="#9653fe"></path><path fill="#5e72e4" d="M410.94 370.856h-22v27.527H157.83v-37.514h-22v59.514h275.11zM178.659 127.208h24.74v22h-24.74z" data-original="#171944" class=""></path><path fill="#5e72e4" d="M89.06 345.86h246.563V215.385H89.06zm22-108.475h202.563v86.475H111.06z" data-original="#9653fe"></path></g></svg><?php }
}
