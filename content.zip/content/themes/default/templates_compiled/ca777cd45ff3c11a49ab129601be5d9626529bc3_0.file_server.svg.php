<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/server.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135e9c818_12948309',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ca777cd45ff3c11a49ab129601be5d9626529bc3' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/server.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135e9c818_12948309 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 48 48" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#57d2fd"><path d="M8 17h8v2H8zM8 13h8v2H8zM37 19c-1.654 0-3-1.346-3-3s1.346-3 3-3 3 1.346 3 3-1.346 3-3 3zm0-4a1.001 1.001 0 0 0 0 2 1.001 1.001 0 0 0 0-2z" fill="#5e72e4" data-original="#57d2fd"></path></g><path fill="#5e72e4" d="M46 12c0-1.65-1.35-3-3-3H5c-1.65 0-3 1.35-3 3v8c0 .76.29 1.47.77 2-.48.53-.77 1.24-.77 2v8c0 1.65 1.35 3 3 3h2v2c0 .55.45 1 1 1h4.33c.43 0 .82-.28.95-.68l.77-2.32h20.23l.77 2.32c.14.4.52.68.95.68h4c.55 0 1-.45 1-1v-2h2c1.65 0 3-1.35 3-3v-8c0-.76-.29-1.47-.77-2 .48-.53.77-1.24.77-2zM11.61 36H9v-1h2.95zM39 36h-2.28l-.33-1H39zm5-4c0 .55-.45 1-1 1H5c-.55 0-1-.45-1-1v-8c0-.55.45-1 1-1h38c.55 0 1 .45 1 1zm0-12c0 .55-.45 1-1 1H5c-.55 0-1-.45-1-1v-8c0-.55.45-1 1-1h38c.55 0 1 .45 1 1z" data-original="#23a6d0" class=""></path><path fill="#5e72e4" d="M8 29h8v2H8zM8 25h8v2H8zM37 31c-1.654 0-3-1.346-3-3s1.346-3 3-3 3 1.346 3 3-1.346 3-3 3zm0-4a1.001 1.001 0 0 0 0 2 1.001 1.001 0 0 0 0-2z" data-original="#57d2fd"></path></g></svg><?php }
}
