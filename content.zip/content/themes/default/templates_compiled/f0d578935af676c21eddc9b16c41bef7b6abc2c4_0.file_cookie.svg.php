<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/cookie.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d9acdf7_80875377',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f0d578935af676c21eddc9b16c41bef7b6abc2c4' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/cookie.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d9acdf7_80875377 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g fill="#2271d5"><circle cx="15" cy="25" r="1" fill="#5e72e4" data-original="#2271d5"></circle><circle cx="25" cy="18" r="1" fill="#5e72e4" data-original="#2271d5"></circle><circle cx="16" cy="15" r="1" fill="#5e72e4" data-original="#2271d5"></circle><circle cx="7" cy="16" r="1" fill="#5e72e4" data-original="#2271d5"></circle></g><path fill="#5e72e4" d="M16 30h-.6C8.2 29.7 2.3 23.8 2 16.5c-.1-3.8 1.3-7.4 3.9-10.2C8.6 3.5 12.2 2 16 2c.8 0 1.6.1 2.5.2.3.1.6.3.7.6s.1.6 0 .9c-.1.2-.2.5-.2.7 0 .5.3.9.7 1.2.9.5 1.2 1.6.7 2.6-.2.5-.3 1-.2 1.6.2 1 1 1.8 2 2 .5.1 1.1.1 1.6-.2 1-.4 2.1-.1 2.6.7.4.6 1.2.9 1.9.5.3-.2.6-.2.9 0 .3.1.5.4.6.7.2.9.2 1.7.2 2.5 0 3.8-1.5 7.4-4.3 10.1-2.6 2.5-6.1 3.9-9.7 3.9zm0-26c-3.3 0-6.4 1.3-8.6 3.7C5.1 10 3.9 13.2 4 16.5c.2 6.1 5.4 11.3 11.5 11.5 3.3.1 6.4-1.1 8.8-3.3 2.4-2.3 3.7-5.4 3.7-8.6v-1c-1.3.1-2.6-.5-3.2-1.6h-.1c-.9.4-1.8.5-2.8.3-1.8-.4-3.2-1.8-3.6-3.6-.2-.9-.1-1.9.3-2.8v-.1c-1-.6-1.6-1.7-1.6-2.9V4h-1z" data-original="#2271d5"></path><path fill="#52baff" d="M19 23c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3zm0-4c-.6 0-1 .4-1 1s.4 1 1 1 1-.4 1-1-.4-1-1-1zM11 14c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3zm0-4c-.6 0-1 .4-1 1s.4 1 1 1 1-.4 1-1-.4-1-1-1zM11 23c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3zm0-4c-.6 0-1 .4-1 1s.4 1 1 1 1-.4 1-1-.4-1-1-1z" data-original="#52baff"></path></g></svg><?php }
}
