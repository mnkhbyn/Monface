<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:10
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/chat_typing.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8122743444_20320256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b1cd78a3b55146f7bd485be25a7db761d441afd7' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/chat_typing.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8122743444_20320256 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g data-name="Layer 2"><path fill="#5e72e4" d="M7.73 22.31a2 2 0 0 1-.79-.16 2 2 0 0 1-1.18-1.51l-.33-2a6 6 0 0 1-1.65-1.27c-2.36-2.74-2.36-10 0-12.74C5.21 3 8.28 2 12 2c3.72 0 6.79 1 8.22 2.63 2.36 2.74 2.36 10 0 12.74-1.71 2-5.47 2.69-8.4 2.62l-3 2a1.94 1.94 0 0 1-1.09.32zM12 4c-3 0-5.7.78-6.71 1.94-1.71 2-1.71 8.13 0 10.12a4 4 0 0 0 1.07.79 2 2 0 0 1 1 1.46l.33 2 3-2a1.8 1.8 0 0 1 1.14-.31c3.1.05 5.85-.75 6.87-1.93 1.72-2 1.72-8.13 0-10.12C17.7 4.78 15 4 12 4z" data-original="#232323"></path><g fill="#7fbde7"><circle cx="8" cy="11" r="1.25" fill="#7fbde7" data-original="#7fbde7"></circle><circle cx="12" cy="11" r="1.25" fill="#7fbde7" data-original="#7fbde7"></circle><circle cx="16" cy="11" r="1.25" fill="#7fbde7" data-original="#7fbde7"></circle></g></g></g></svg><?php }
}
