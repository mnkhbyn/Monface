<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/resolution.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135a14a59_80839670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b3358adf0bae34120dc952a3dac52238bd436aab' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/resolution.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135a14a59_80839670 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M176 512H64c-35.348 0-64-28.652-64-64V320c0-35.348 28.652-64 64-64h112c35.348 0 64 28.652 64 64v128c0 35.348-28.652 64-64 64zM64 288c-17.672 0-32 14.328-32 32v128c0 17.672 14.328 32 32 32h112c17.672 0 32-14.328 32-32V320c0-17.672-14.328-32-32-32zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M32 208c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M32 144c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M32 80c0 8.836-7.164 16-16 16S0 88.836 0 80s7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M32 16c0 8.836-7.164 16-16 16S0 24.836 0 16 7.164 0 16 0s16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M96 16c0 8.836-7.164 16-16 16s-16-7.164-16-16S71.164 0 80 0s16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M160 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M224 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M288 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M352 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M416 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M480 16c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M480 80c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M480 144c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M480 208c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M480 272c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M480 336c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M480 400c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M480 464c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M416 464c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><path fill="#5e72e4" d="M352 464c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#f03d8f"></path><path fill="#7c21ff" d="M288 464c0 8.836-7.164 16-16 16s-16-7.164-16-16 7.164-16 16-16 16 7.164 16 16zm0 0" data-original="#7c21ff" class=""></path><g fill="#f03d8f"><path d="M384 160c-8.836 0-16-7.164-16-16v-32h-32c-8.836 0-16-7.164-16-16s7.164-16 16-16h32a31.357 31.357 0 0 1 22.828 9.172A31.357 31.357 0 0 1 400 112v32c0 8.836-7.164 16-16 16zm0 0" fill="#5e72e4" data-original="#f03d8f"></path><path d="M272 224a15.991 15.991 0 0 1-14.777-9.879 15.999 15.999 0 0 1 3.465-17.434l96-96a16 16 0 1 1 22.625 22.626l-96 96c-3 3-7.07 4.687-11.313 4.687zm0 0" fill="#5e72e4" data-original="#f03d8f"></path><path d="M304 240h-32a31.357 31.357 0 0 1-22.828-9.172A31.357 31.357 0 0 1 240 208v-32c0-8.836 7.164-16 16-16s16 7.164 16 16v32h32c8.836 0 16 7.164 16 16s-7.164 16-16 16zm0 0" fill="#5e72e4" data-original="#f03d8f"></path></g></g></svg><?php }
}
