<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/directory.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d528184_64200029',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8e42d6d3ca5e5a4cd4b87cac11e8a77d2968431e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/directory.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d528184_64200029 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M19 3h-8.74a5.066 5.066 0 0 0-3.171-.804c-.95.075-1.863.171-2.739.28A4.973 4.973 0 0 0 0 7.43v11.13a5.024 5.024 0 0 0 4.416 4.974A62.594 62.594 0 0 0 12 24a60.737 60.737 0 0 0 7.65-.477A4.973 4.973 0 0 0 24 18.57V8a5.006 5.006 0 0 0-5-5zm3 5v.026A4.951 4.951 0 0 0 19 7h-3.343a3.02 3.02 0 0 1-2.121-.879L12.415 5H19a3.003 3.003 0 0 1 3 3zm0 10.57a2.972 2.972 0 0 1-2.597 2.968 59.99 59.99 0 0 1-14.743.01A3.023 3.023 0 0 1 2 18.56V7.43a2.972 2.972 0 0 1 2.594-2.968q1.278-.16 2.654-.272c.084-.006.168-.01.252-.01a3.029 3.029 0 0 1 2.145.879l2.477 2.476A4.968 4.968 0 0 0 15.657 9H19a3.003 3.003 0 0 1 3 3z" data-original="#212529" class=""></path><path fill="#5e72e4" d="M20 17H4a1 1 0 0 0 0 2h16a1 1 0 0 0 0-2z" data-original="#5cfaa9" class=""></path></g></svg><?php }
}
