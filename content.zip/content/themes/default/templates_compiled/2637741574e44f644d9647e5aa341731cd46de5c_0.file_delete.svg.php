<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:10
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/delete.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8122826e80_61476967',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2637741574e44f644d9647e5aa341731cd46de5c' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/delete.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8122826e80_61476967 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M20.75 6v.5A1.75 1.75 0 0 1 19 8.25H5A1.75 1.75 0 0 1 3.25 6.5V6c0-.966.783-1.75 1.75-1.75h14c.967 0 1.75.784 1.75 1.75zm-1.5 0a.25.25 0 0 0-.25-.25H5a.25.25 0 0 0-.25.25v.5c0 .138.112.25.25.25h14a.25.25 0 0 0 .25-.25z" fill="#5e72e4" data-original="#000000" class=""></path><path d="m19.748 7.552-.871 12.637a2.75 2.75 0 0 1-2.744 2.561H7.867a2.75 2.75 0 0 1-2.744-2.561L4.252 7.552A.747.747 0 0 1 5 6.75h14a.75.75 0 0 1 .748.802zm-1.552.698H5.804l.816 11.836a1.25 1.25 0 0 0 1.247 1.164h8.266a1.25 1.25 0 0 0 1.247-1.164zM7.25 4.987V4c0-.729.29-1.429.805-1.945A2.755 2.755 0 0 1 10 1.25h4c.729 0 1.429.29 1.945.805.515.516.805 1.216.805 1.945v.987c0 .704-.75.763-.75.763a.75.75 0 0 1-.75-.75V4A1.252 1.252 0 0 0 14 2.75h-4A1.252 1.252 0 0 0 8.75 4v.987c0 .704-.75.763-.75.763A.75.75 0 0 1 7.25 5v-.013z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M11.25 11a.75.75 0 0 1 1.5 0v7.5a.75.75 0 0 1-1.5 0zM7.752 11.05a.75.75 0 1 1 1.496-.1l.5 7.5a.75.75 0 1 1-1.496.1zM14.752 10.95a.75.75 0 1 1 1.496.1l-.5 7.5a.75.75 0 1 1-1.496-.1z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
