<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:55
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/watch.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c630f5124_37031447',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4deec4e016babf7ef0cedcccaf8c0908c0c655b3' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/watch.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c630f5124_37031447 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><g fill="#232323"><path d="M19 18h-1.5a1 1 0 0 1 0-2H19a2.003 2.003 0 0 0 2-2V5a2.003 2.003 0 0 0-2-2H5a2.003 2.003 0 0 0-2 2v9a2.003 2.003 0 0 0 2 2h9a1 1 0 0 1 0 2H5a4.004 4.004 0 0 1-4-4V5a4.004 4.004 0 0 1 4-4h14a4.004 4.004 0 0 1 4 4v9a4.004 4.004 0 0 1-4 4zM7 22H2a1 1 0 0 1 0-2h5a1 1 0 0 1 0 2zM22 22H10a1 1 0 0 1 0-2h12a1 1 0 0 1 0 2z" fill="#5e72e4" data-original="#232323" class=""></path></g><path fill="#7fbde7" d="M10.23 13.502a1.892 1.892 0 0 1-1.885-1.889V7.387a1.887 1.887 0 0 1 2.731-1.688l4.226 2.114a1.885 1.885 0 0 1-.001 3.375L11.076 13.3a1.895 1.895 0 0 1-.846.201zm.115-5.933v3.862l3.86-1.931z" data-original="#7fbde7" class=""></path><path fill="#5e72e4" d="M7 23.5a1 1 0 0 1-1-1v-3a1 1 0 0 1 2 0v3a1 1 0 0 1-1 1z" data-original="#232323" class=""></path></g></g></svg><?php }
}
