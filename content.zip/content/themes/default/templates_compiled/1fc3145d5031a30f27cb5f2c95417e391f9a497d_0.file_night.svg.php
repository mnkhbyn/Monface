<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/night.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c664fd2d2_37117176',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1fc3145d5031a30f27cb5f2c95417e391f9a497d' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/night.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c664fd2d2_37117176 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M371.055 415.019c-83.72 30.472-176.291-12.695-206.763-96.416-30.472-83.721 12.695-176.292 96.415-206.764a161.75 161.75 0 0 1 3.747-1.31c-38.906-11.092-81.54-10.473-122.463 4.421C38.715 152.54-14.534 266.734 23.055 370.009c37.589 103.276 151.783 156.525 255.058 118.935 40.923-14.895 73.981-41.825 96.655-75.331-1.229.482-2.466.952-3.713 1.406z" style="stroke-width:22;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" fill="none" stroke="#5e72e4" stroke-width="22" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" data-original="#000000"></path><path d="m423.653 11 23.902 48.43L501 67.196l-38.673 37.697 9.129 53.229-47.803-25.131-47.802 25.131 9.129-53.229-38.673-37.697 53.445-7.766zM306.836 207.418l18.848 38.191 42.147 6.125-30.498 29.728 7.2 41.976-37.697-19.819-37.698 19.819 7.2-41.976-30.498-29.728 42.147-6.125z" style="stroke-width:22;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" fill="none" stroke="#33cccc" stroke-width="22" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" data-original="#33cccc" class=""></path></g></svg><?php }
}
