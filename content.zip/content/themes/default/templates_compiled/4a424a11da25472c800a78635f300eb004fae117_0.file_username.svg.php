<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/username.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80cea930d1_31945925',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4a424a11da25472c800a78635f300eb004fae117' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/username.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80cea930d1_31945925 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M16 31c-2.573 0-5.109-.672-7.363-1.947l-4.57 1.372a2 2 0 0 1-2.491-2.49l1.372-4.571a14.956 14.956 0 0 1-1.947-7.363C1 7.729 7.729 1 16 1s15 6.729 15 15-6.729 15-15 15zm-7.233-4.03c.181 0 .36.049.519.145a12.956 12.956 0 0 0 6.715 1.886c7.168 0 13-5.832 13-13S23.168 3 16 3 3 8.832 3 16c0 2.357.652 4.679 1.886 6.715.146.242.184.535.103.806l-1.497 4.988 4.988-1.497c.094-.028.19-.042.287-.042z" data-original="#06474d" class=""></path><path fill="#3cacb6" d="M16.184 9.002a6.964 6.964 0 0 0-5.068 1.984A6.946 6.946 0 0 0 9.001 16c0 3.86 3.141 7 7 7a1 1 0 1 0 0-2c-2.757 0-5-2.243-5-5 0-1.36.536-2.632 1.511-3.582a4.907 4.907 0 0 1 3.622-1.417c2.684.069 4.867 2.436 4.867 5.276v1.722a1.001 1.001 0 0 1-2 0v-2c0-1.654-1.346-3-3-3s-3 1.346-3 3 1.346 3 3 3c.395 0 .77-.081 1.116-.22a2.995 2.995 0 0 0 2.884 2.22c1.654 0 3-1.346 3-3v-1.722c0-3.915-3.058-7.179-6.816-7.275zM16 17a1.001 1.001 0 0 1 0-2 1.001 1.001 0 0 1 0 2z" data-original="#3cacb6"></path></g></svg><?php }
}
