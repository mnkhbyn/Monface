<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:50
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/alipay.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e814a25bfc8_15799070',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3d4503aaaed7c4c4d7287655ca876a272e928ffd' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/alipay.svg',
      1 => 1638112703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e814a25bfc8_15799070 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0" encoding="UTF-8"<?php echo '?>'; ?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 48 48" xml:space="preserve"><path d="M42 11v27a4 4 0 0 1-4 4H11a5 5 0 0 1-5-5V11a5 5 0 0 1 5-5h26a5 5 0 0 1 5 5z" fill="#5B9EDD"/><path d="M29.91 27.17C32 23.641 33 19 33 19h-7v-2h9v-2h-9v-3.98L22 11v4h-9v2h9v2h-8v2s13.125 0 14.5-.01c-.281.793-.99 3.189-2.015 5.055C22.602 24.84 19.019 24 16.143 24c-6.898 0-8.428 3.481-8.102 6.664.263 2.54 2.145 6.248 7.893 6.248 5.251 0 9.49-3.023 12.099-6.622C33.008 32.591 38.263 34.909 42 37v-6.038c-3.951-1.361-8.11-2.431-12.09-3.792zm-14.812 7.592c-4.858 0-5.61-2.75-5.694-4.392-.079-1.436.886-4.132 6.371-4.132 2.04 0 5.276 1.046 8.909 2.57-2.053 2.708-5.343 5.954-9.586 5.954z" fill="#FFF"/><metadata><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:dc="http://purl.org/dc/elements/1.1/"><rdf:Description about="https://iconscout.com/legal#licenses" dc:title="alipay" dc:description="alipay" dc:publisher="Iconscout" dc:date="2017-12-15" dc:format="image/svg+xml" dc:language="en"><dc:creator><rdf:Bag><rdf:li>Icons8</rdf:li></rdf:Bag></dc:creator></rdf:Description></rdf:RDF></metadata></svg><?php }
}
