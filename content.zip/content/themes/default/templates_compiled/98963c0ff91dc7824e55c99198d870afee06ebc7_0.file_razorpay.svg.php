<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:50
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/razorpay.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e814a48f645_15490624',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98963c0ff91dc7824e55c99198d870afee06ebc7' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/razorpay.svg',
      1 => 1651285678,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e814a48f645_15490624 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="#2d8ff0" d="m22.436 0l-11.91 7.773l-1.174 4.276l6.625-4.297L11.65 24h4.391l6.395-24zM14.26 10.098L3.389 17.166L1.564 24h9.008l3.688-13.902Z"/></svg><?php }
}
