<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/website_public.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d4b1b16_98037253',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '45f02a973902be5f80a021b7e1c7b906c5fc91d0' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/website_public.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d4b1b16_98037253 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#7fbde7" d="M12 22.75a.75.75 0 0 1-.75-.75V2a.75.75 0 0 1 1.5 0v20a.75.75 0 0 1-.75.75z" data-original="#7fbde7" class=""></path><path fill="#5e72e4" d="M19.79 19.02a.748.748 0 0 1-.254-.044 19.762 19.762 0 0 0-3.44-.875 24.186 24.186 0 0 0-8.183-.002 19.825 19.825 0 0 0-3.45.877.75.75 0 0 1-.507-1.413 21.45 21.45 0 0 1 3.701-.943 25.787 25.787 0 0 1 8.695.002 21.39 21.39 0 0 1 3.692.942.75.75 0 0 1-.254 1.456z" data-original="#232323" class=""></path><path fill="#7fbde7" d="M22 12.75H2a.75.75 0 0 1 0-1.5h20a.75.75 0 0 1 0 1.5z" data-original="#7fbde7" class=""></path><path fill="#5e72e4" d="M12 7.75a24.744 24.744 0 0 1-4.353-.372 21.39 21.39 0 0 1-3.691-.941.75.75 0 0 1 .508-1.413 19.762 19.762 0 0 0 3.44.875 24.186 24.186 0 0 0 8.183.002 19.825 19.825 0 0 0 3.45-.877.75.75 0 0 1 .507 1.413 21.45 21.45 0 0 1-3.701.943A24.74 24.74 0 0 1 12 7.75z" data-original="#232323" class=""></path><path fill="#7fbde7" d="M12 22.75c-3.225 0-5.75-4.722-5.75-10.75S8.775 1.25 12 1.25 17.75 5.972 17.75 12 15.225 22.75 12 22.75zm0-20c-2.053 0-4.25 3.717-4.25 9.25s2.197 9.25 4.25 9.25 4.25-3.717 4.25-9.25S14.053 2.75 12 2.75z" data-original="#7fbde7" class=""></path><path fill="#5e72e4" d="M12 22.75A10.75 10.75 0 1 1 22.75 12 10.762 10.762 0 0 1 12 22.75zm0-20A9.25 9.25 0 1 0 21.25 12 9.26 9.26 0 0 0 12 2.75z" data-original="#232323" class=""></path></g></g></svg><?php }
}
