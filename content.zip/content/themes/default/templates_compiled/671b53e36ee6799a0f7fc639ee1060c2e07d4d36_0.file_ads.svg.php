<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:51:55
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/ads.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e818b998d33_83361480',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '671b53e36ee6799a0f7fc639ee1060c2e07d4d36' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/ads.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e818b998d33_83361480 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M15 16.56a2.11 2.11 0 0 1-.7-.13l-6-2.24A2.93 2.93 0 0 0 7.27 14H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h1.27a2.93 2.93 0 0 0 1.06-.19l6-2.24A2 2 0 0 1 17 3.44v11.12a2 2 0 0 1-2 2zM6 6a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h1.27a5 5 0 0 1 1.73.32l6 2.24V3.44L9 5.68A5 5 0 0 1 7.27 6z" data-original="#232323"></path><g fill="#7fbde7"><path d="M21 10h-2a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2zM19 7a1 1 0 0 1-.89-.55 1 1 0 0 1 .44-1.34l2-1a1 1 0 1 1 .9 1.78l-2 1A.93.93 0 0 1 19 7zM21 14a.93.93 0 0 1-.45-.11l-2-1a1 1 0 1 1 .9-1.78l2 1a1 1 0 0 1 .44 1.34A1 1 0 0 1 21 14z" fill="#7fbde7" data-original="#7fbde7"></path></g><path fill="#5e72e4" d="M8.72 21a3 3 0 0 1-3-2.56L5 13.14a1 1 0 0 1 2-.28l.76 5.3a1 1 0 0 0 1 .84 1 1 0 0 0 1-1.12l-.08-.57a1 1 0 0 1 2-.28l.08.57A3 3 0 0 1 8.72 21z" data-original="#232323"></path></g></g></svg><?php }
}
