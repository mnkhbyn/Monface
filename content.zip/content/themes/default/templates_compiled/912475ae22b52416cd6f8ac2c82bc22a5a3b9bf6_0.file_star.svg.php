<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:52
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/star.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c9cdb1532_98066221',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '912475ae22b52416cd6f8ac2c82bc22a5a3b9bf6' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/star.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c9cdb1532_98066221 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 200 200" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M150.68 194a18.46 18.46 0 0 1-8.39-2L100 170.37 57.71 192a18.42 18.42 0 0 1-26.51-19.65l7.94-44.95L5.77 95.82A18.43 18.43 0 0 1 15.86 64.2l46.6-6.57 21.12-41.55a18.42 18.42 0 0 1 32.84 0l21.12 41.55 46.6 6.57a18.43 18.43 0 0 1 10.09 31.62l-33.37 31.58 7.94 44.95A18.45 18.45 0 0 1 150.68 194zM100 155.51a7 7 0 0 1 3.18.77l45.48 23.21a4.28 4.28 0 0 0 4.63-.38 4.34 4.34 0 0 0 1.73-4.33l-8.6-48.66a7 7 0 0 1 2.08-6.3l36.1-34.17a4.42 4.42 0 0 0-2.42-7.58L132 71a7 7 0 0 1-5.26-3.76l-22.8-44.81a4.42 4.42 0 0 0-7.88 0L73.29 67.22A7 7 0 0 1 68 71l-50.18 7.07a4.41 4.41 0 0 0-2.42 7.58l36.1 34.17a7 7 0 0 1 2.08 6.3L45 174.78a4.42 4.42 0 0 0 6.36 4.71l45.48-23.21a7 7 0 0 1 3.16-.77z" data-original="#00a5ec"></path></g></svg><?php }
}
