<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/games.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d773e32_61905712',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '95889bcb6f2e83cae4cf1ac4e74095ff9fb71161' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/games.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d773e32_61905712 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M16 22.75H8c-3.65 0-5.75-2.1-5.75-5.75V7c0-3.65 2.1-5.75 5.75-5.75h8c3.65 0 5.75 2.1 5.75 5.75v10c0 3.65-2.1 5.75-5.75 5.75zm-8-20C5.14 2.75 3.75 4.14 3.75 7v10c0 2.86 1.39 4.25 4.25 4.25h8c2.86 0 4.25-1.39 4.25-4.25V7c0-2.86-1.39-4.25-4.25-4.25z" data-original="#000000" class=""></path><path fill="#5e72e4" d="M16.25 11.75h-8.5a2.5 2.5 0 0 1-2.5-2.5v-2.5a2.5 2.5 0 0 1 2.5-2.5h8.5a2.5 2.5 0 0 1 2.5 2.5v2.5a2.5 2.5 0 0 1-2.5 2.5zm-8.5-6c-.55 0-1 .45-1 1v2.5c0 .55.45 1 1 1h8.5c.55 0 1-.45 1-1v-2.5c0-.55-.45-1-1-1z" data-original="#aaaaaa" class=""></path><path fill="#5e72e4" d="M8 18.33c-.19 0-.38-.07-.53-.22a.754.754 0 0 1 0-1.06l2.3-2.3c.29-.29.77-.29 1.06 0s.29.77 0 1.06l-2.3 2.3c-.15.15-.34.22-.53.22z" data-original="#000000" class=""></path><path fill="#5e72e4" d="M10.33 18.36c-.19 0-.38-.07-.53-.22l-2.3-2.3c-.29-.29-.29-.77 0-1.06s.77-.29 1.06 0l2.3 2.3c.29.29.29.77 0 1.06-.15.15-.34.22-.53.22z" data-original="#000000" class=""></path><g fill="#aaa"><path d="M16.51 16.33c-.55 0-1.01-.45-1.01-1s.44-1 .99-1h.02c.55 0 1 .45 1 1s-.45 1-1 1zM14.49 18.49c-.55 0-1-.44-1-.99v-.02c0-.55.45-1 1-1s1 .45 1 1-.45 1.01-1 1.01z" fill="#5e72e4" data-original="#aaaaaa" class=""></path></g></g></svg><?php }
}
