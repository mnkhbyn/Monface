<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/wasabi.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135d582c6_54879399',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd4ec7d83dbadbdf6146b199d05004d142ee65104' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/wasabi.svg',
      1 => 1642437641,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135d582c6_54879399 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 66 66" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#A" x=".5" y=".5"/><symbol id="A" overflow="visible"><path d="M54.628 9.373C42.131-3.124 21.87-3.124 9.373 9.373s-12.497 32.758 0 45.255 32.758 12.497 45.255 0 12.497-32.758 0-45.255zm3.458 19.722L44.307 16.591l-21.5 20.278V26.491l11.222-10.665 8.382-7.92c8.64 3.749 14.618 11.83 15.675 21.189zm-.235 7.546a26.08 26.08 0 0 1-2.755 7.858l-7.85-7.16V26.951zM36.014 6.051l-5.93 5.604-7.297 6.92V7.421a26.29 26.29 0 0 1 13.236-1.368zM17.047 37.057L6.171 27.293a26.08 26.08 0 0 1 2.858-7.986l8.02 7.198zm0-26.613v8.335l-4.67-4.2c1.387-1.562 2.954-2.954 4.67-4.146zM5.891 34.755l14.094 12.642 21.486-20.222v10.198l-19.82 18.75A26.31 26.31 0 0 1 5.892 34.755zm22.16 23.196l13.415-12.684v11.208c-3.02 1.172-6.232 1.772-9.472 1.769-1.321.001-2.641-.096-3.948-.292zm19.16-4.575v-8.292l4.575 4.142a26.55 26.55 0 0 1-4.561 4.151z" stroke="none" fill="#00ce3e" fill-rule="nonzero"/></symbol></svg><?php }
}
