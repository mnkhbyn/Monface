<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/forums.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d5a5e20_73887909',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d61c9541e17cf3605ba13800673ec9a23ddc830' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/forums.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d5a5e20_73887909 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 64 64" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M20.146 10.457h-1a2 2 0 0 1 0-4h1a2 2 0 0 1 0 4z" data-original="#0cc121"></path><path fill="#5e72e4" d="M13.146 10.457h-4a2 2 0 0 1 0-4h4a2 2 0 0 1 0 4zM43.752 10.457H26.146a2 2 0 0 1 0-4h17.605a2 2 0 0 1 .001 4zM24.2 49.744a2 2 0 0 1-2-2v-9.4a2 2 0 0 1 4 0v9.4a2 2 0 0 1-2 2zM55.4 27.645h-8.502a2 2 0 0 1 0-4H55.4a2 2 0 0 1 0 4zM55.4 52.344h-1.791a2 2 0 0 1 0-4H55.4a2 2 0 0 1 0 4z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M45.144 52.344H26.8a2 2 0 0 1 0-4h18.344a2 2 0 0 1 0 4z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M53.607 57.543c-.357 0-.719-.096-1.045-.295l-8.466-5.201a1.999 1.999 0 1 1 2.094-3.408l8.466 5.201a1.999 1.999 0 0 1-1.049 3.703z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M53.609 57.543a2 2 0 0 1-2-2v-5.199a2 2 0 0 1 4 0v5.199a2 2 0 0 1-2 2zM58 49.744a2 2 0 0 1-2-2v-19.5a2 2 0 0 1 4 0v19.5a2 2 0 0 1-2 2zM26.8 52.344a4.606 4.606 0 0 1-4.6-4.6 2 2 0 0 1 4 0c0 .33.269.6.6.6a2 2 0 0 1 0 4z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M55.4 52.344a2 2 0 0 1 0-4c.331 0 .6-.27.6-.6a2 2 0 0 1 4 0c0 2.535-2.063 4.6-4.6 4.6zM58 30.244a2 2 0 0 1-2-2 .6.6 0 0 0-.6-.6 2 2 0 0 1 0-4c2.536 0 4.6 2.063 4.6 4.6a2 2 0 0 1-2 2zM22 18.457h-8a2 2 0 0 1 0-4h8a2 2 0 0 1 0 4zM30 26.457H14a2 2 0 0 1 0-4h16a2 2 0 0 1 0 4zM43.752 40.344H21.557a2 2 0 0 1 0-4h22.195a2 2 0 0 1 0 4zM46.898 13.604a2 2 0 0 1-2-2c0-.633-.515-1.146-1.146-1.146a2 2 0 0 1 0-4 5.152 5.152 0 0 1 5.146 5.146 2 2 0 0 1-2 2zM6 13.604a2 2 0 0 1-2-2 5.152 5.152 0 0 1 5.146-5.146 2 2 0 0 1 0 4A1.147 1.147 0 0 0 8 11.604c0 1.103-.896 2-2 2zM9.146 40.344A5.153 5.153 0 0 1 4 35.197a2 2 0 0 1 4 0c0 .633.515 1.146 1.146 1.146a2 2 0 0 1 0 4.001z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M43.752 40.344a2 2 0 0 1 0-4c.632 0 1.146-.514 1.146-1.146a2 2 0 0 1 4 0 5.152 5.152 0 0 1-5.146 5.146zM6 37.197a2 2 0 0 1-2-2V11.604a2 2 0 0 1 4 0v23.594a2 2 0 0 1-2 1.999z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M46.898 37.197a2 2 0 0 1-2-2V11.604a2 2 0 0 1 4 0v23.594a1.999 1.999 0 0 1-2 1.999zM11.313 46.635a2 2 0 0 1-2-2v-6.291a2 2 0 0 1 4 0v6.291a2 2 0 0 1-2 2z" data-original="#262626" class=""></path><path fill="#5e72e4" d="M11.314 46.635a1.998 1.998 0 0 1-1.049-3.703l10.244-6.293a1.999 1.999 0 1 1 2.094 3.408L12.359 46.34a2.003 2.003 0 0 1-1.045.295zM11.313 40.344H9.146a2 2 0 0 1 0-4h2.166a2 2 0 0 1 .001 4z" data-original="#262626" class=""></path></g></svg><?php }
}
