<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/genders.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80cea226b9_05748921',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '94f18bb5b1cfef06be14d8ee1338440bf1edbe51' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/genders.svg',
      1 => 1685363919,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80cea226b9_05748921 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg id="Line_Expand" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg" data-name="Line Expand"><path d="m6.1 17.313 3.713-3.713a7.018 7.018 0 1 0 -1.413-1.414l-3.714 3.714-1.414-1.415a1 1 0 0 0 -1.414 1.415l1.414 1.415-1.979 1.978a1 1 0 1 0 1.414 1.414l1.979-1.979 1.414 1.414a1 1 0 1 0 1.414-1.414zm7.9-14.313a5 5 0 1 1 -5 5 5 5 0 0 1 5-5z"/><path d="m30 11h-5a1 1 0 0 0 0 2h2.586l-5.4 5.4a7.018 7.018 0 1 0 1.414 1.414l5.4-5.4v2.586a1 1 0 0 0 2 0v-5a1 1 0 0 0 -1-1zm-12 18a5 5 0 1 1 5-5 5 5 0 0 1 -5 5z"/></svg><?php }
}
