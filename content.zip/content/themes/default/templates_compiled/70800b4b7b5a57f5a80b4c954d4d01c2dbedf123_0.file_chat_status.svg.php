<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:10
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/chat_status.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e81226d5762_12661703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '70800b4b7b5a57f5a80b4c954d4d01c2dbedf123' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/chat_status.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e81226d5762_12661703 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 64 64" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 16"><g fill="#39b54a"><path d="M14.2 27.3h-7a4.7 4.7 0 0 0 0 9.4h7a4.7 4.7 0 0 0 0-9.4zm1.69 4.7a1.7 1.7 0 0 1-1.69 1.7h-7a1.7 1.7 0 1 1 0-3.4h7a1.7 1.7 0 0 1 1.69 1.7zM32 2.5a4.71 4.71 0 0 0-4.7 4.7v7a4.7 4.7 0 0 0 9.4 0v-7A4.71 4.71 0 0 0 32 2.5zm1.7 11.7a1.7 1.7 0 0 1-3.4 0v-7a1.7 1.7 0 0 1 3.4 0zM56.8 27.3h-7a4.7 4.7 0 0 0 0 9.4h7a4.7 4.7 0 1 0 0-9.4zm1.7 4.7a1.7 1.7 0 0 1-1.7 1.7h-7a1.7 1.7 0 0 1 0-3.4h7a1.7 1.7 0 0 1 1.7 1.7zM32 45.11a4.7 4.7 0 0 0-4.7 4.69v7a4.7 4.7 0 0 0 9.4 0v-7a4.7 4.7 0 0 0-4.7-4.69zm1.7 11.69a1.7 1.7 0 0 1-3.4 0v-7a1.7 1.7 0 0 1 3.4 0z" fill="#5e72e4" data-original="#39b54a" class=""></path></g><path d="M17.78 11.14a4.7 4.7 0 0 0-6.64 6.64l4.95 4.95a4.7 4.7 0 0 0 6.64-6.64zm2.83 9.47a1.74 1.74 0 0 1-2.4 0l-5-4.95a1.7 1.7 0 0 1 2.4-2.4l4.95 5a1.7 1.7 0 0 1 .05 2.35zM52.86 46.22l-5-4.95a4.7 4.7 0 0 0-6.64 6.64l4.95 5a4.71 4.71 0 0 0 6.64 0 4.71 4.71 0 0 0 0-6.64zm-2.12 4.52a1.7 1.7 0 0 1-2.4 0l-5-5a1.7 1.7 0 1 1 2.4-2.4l5 5a1.7 1.7 0 0 1 0 2.4zM19.41 39.89a4.67 4.67 0 0 0-3.32 1.38l-4.95 4.95a4.71 4.71 0 0 0 0 6.64 4.71 4.71 0 0 0 6.64 0l4.95-5a4.7 4.7 0 0 0 0-6.64 4.65 4.65 0 0 0-3.32-1.33zm1.2 5.9-4.95 5a1.7 1.7 0 1 1-2.4-2.4l5-5a1.7 1.7 0 0 1 2.4 2.4z" fill="#5e72e4" data-original="#000000" class=""></path></g></g></svg><?php }
}
