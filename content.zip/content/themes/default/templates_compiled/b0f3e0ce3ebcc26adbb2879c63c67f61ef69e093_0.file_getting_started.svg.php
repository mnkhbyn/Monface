<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/getting_started.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e809998d642_28846320',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b0f3e0ce3ebcc26adbb2879c63c67f61ef69e093' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/getting_started.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e809998d642_28846320 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#7fbde7" d="M9.4 15.75a1.16 1.16 0 0 1-1.09-1.52l1.23-3.7a1.62 1.62 0 0 1 1-1l3.7-1.23a1.16 1.16 0 0 1 1.46 1.46l-1.23 3.7a1.62 1.62 0 0 1-1 1l-3.7 1.23a1.19 1.19 0 0 1-.37.06zM14 10l-3 1-1 3.08 3-1z" data-original="#7fbde7"></path><path fill="#7fbde7" d="M13.55 14.3a.74.74 0 0 1-.53-.22L9.92 11A.75.75 0 1 1 11 9.92l3.1 3.1a.74.74 0 0 1 0 1.06.71.71 0 0 1-.55.22z" data-original="#7fbde7"></path><g fill="#232323"><path d="M12 22.75A10.75 10.75 0 1 1 22.75 12 10.76 10.76 0 0 1 12 22.75zm0-20A9.25 9.25 0 1 0 21.25 12 9.26 9.26 0 0 0 12 2.75z" fill="#5e72e4" data-original="#232323" class=""></path><path d="M12 5.82a.76.76 0 0 1-.75-.75V4a.75.75 0 0 1 1.5 0v1.07a.76.76 0 0 1-.75.75zM16.9 7.85a.79.79 0 0 1-.53-.22.75.75 0 0 1 0-1.06l.76-.76a.75.75 0 0 1 1.06 1.06l-.76.76a.77.77 0 0 1-.53.22zM20 12.75h-1.07a.75.75 0 0 1 0-1.5H20a.75.75 0 0 1 0 1.5zM17.66 18.41a.77.77 0 0 1-.53-.22l-.76-.76a.75.75 0 1 1 1.06-1.06l.76.76a.75.75 0 0 1 0 1.06.79.79 0 0 1-.53.22zM12 20.75a.76.76 0 0 1-.75-.75v-1.07a.75.75 0 0 1 1.5 0V20a.76.76 0 0 1-.75.75zM6.34 18.41a.79.79 0 0 1-.53-.22.75.75 0 0 1 0-1.06l.76-.76a.75.75 0 1 1 1.06 1.06l-.76.76a.75.75 0 0 1-.53.22zM5.07 12.75H4a.75.75 0 0 1 0-1.5h1.07a.75.75 0 0 1 0 1.5zM7.1 7.85a.77.77 0 0 1-.53-.22l-.76-.76a.75.75 0 0 1 1.06-1.06l.76.76a.75.75 0 0 1 0 1.06.79.79 0 0 1-.53.22z" fill="#5e72e4" data-original="#232323" class=""></path></g></g></g></svg><?php }
}
