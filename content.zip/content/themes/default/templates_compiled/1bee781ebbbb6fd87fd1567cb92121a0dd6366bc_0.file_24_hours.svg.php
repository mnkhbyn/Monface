<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/24_hours.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c61082118_96680653',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1bee781ebbbb6fd87fd1567cb92121a0dd6366bc' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/24_hours.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c61082118_96680653 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#06474d"><path d="M13 11.001h-3a1 1 0 1 0 0 2h3v2h-2c-1.103 0-2 .897-2 2v2c0 1.103.897 2 2 2h3a1 1 0 1 0 0-2h-3v-2h2c1.103 0 2-.897 2-2v-2c0-1.103-.897-2-2-2zM22 11.001a1 1 0 0 0-1 1v3h-1c-.552 0-1-.449-1-1v-2a1 1 0 1 0-2 0v2c0 1.654 1.346 3 3 3h1v3a1 1 0 1 0 2 0v-8a1 1 0 0 0-1-1z" fill="#5e72e4" data-original="#06474d"></path><path d="M30.948 21.685a.998.998 0 0 0-1.265-.632l-.743.248a14.053 14.053 0 0 0 1.059-5.299c0-7.72-6.28-14-14-14S2 8.281 2 16.001s6.28 14 14 14a1 1 0 1 0 0-2c-6.617 0-12-5.383-12-12s5.383-12 12-12 12 5.383 12 12c0 1.493-.288 2.976-.826 4.359l-.226-.676a1 1 0 0 0-1.897.633l1 3a1 1 0 0 0 1.264.632l3-1a1 1 0 0 0 .632-1.265z" fill="#5e72e4" data-original="#06474d"></path></g><path fill="#3cacb6" d="M18.29 27.941c-.181.19-.29.45-.29.71 0 .27.109.52.29.71.189.19.45.29.71.29s.52-.1.71-.29c.18-.19.29-.44.29-.71 0-.26-.11-.52-.29-.71-.37-.37-1.05-.37-1.42 0zM22.71 26.791a1.01 1.01 0 0 0-.91-.27c-.06.01-.12.03-.18.06a.763.763 0 0 0-.181.09l-.149.12c-.09.1-.16.21-.21.33s-.08.25-.08.38.03.26.08.38c.05.13.12.23.21.33l.149.12c.061.04.12.07.181.09.06.03.12.05.18.06.07.01.13.02.2.02.26 0 .52-.11.71-.29.18-.19.29-.45.29-.71 0-.13-.021-.26-.08-.38-.05-.12-.12-.23-.21-.33zM25.21 24.991c-.38-.37-1.04-.37-1.42 0-.181.19-.29.45-.29.71s.109.52.29.71c.189.18.45.29.71.29s.52-.11.71-.29c.18-.19.29-.45.29-.71s-.11-.52-.29-.71z" data-original="#3cacb6"></path></g></svg><?php }
}
