<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/biography.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80cec97649_23898049',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c928359e35db7a20d07a4cb6144b6e9585715524' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/biography.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80cec97649_23898049 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M27 6H5C3.346 6 2 7.346 2 9v16c0 1.654 1.346 3 3 3h22c1.654 0 3-1.346 3-3V9c0-1.654-1.346-3-3-3zm1 19c0 .551-.448 1-1 1H5c-.552 0-1-.449-1-1V9c0-.551.448-1 1-1h22c.552 0 1 .449 1 1z" data-original="#06474d"></path><path fill="#5e72e4" d="M13.793 17.855A3.984 3.984 0 0 0 15 15c0-2.206-1.794-4-4-4s-4 1.794-4 4c0 1.119.464 2.128 1.207 2.855A5 5 0 0 0 6 22a1 1 0 1 0 2 0c0-1.654 1.346-3 3-3s3 1.346 3 3a1 1 0 1 0 2 0 4.999 4.999 0 0 0-2.207-4.145zM9 15c0-1.103.897-2 2-2s2 .897 2 2-.897 2-2 2-2-.897-2-2z" data-original="#06474d"></path><g fill="#3cacb6"><path d="M25 13h-6a1 1 0 1 1 0-2h6a1 1 0 1 1 0 2zM25 23h-6a1 1 0 1 1 0-2h6a1 1 0 1 1 0 2zM25 18h-6a1 1 0 1 1 0-2h6a1 1 0 1 1 0 2z" fill="#3cacb6" data-original="#3cacb6"></path></g></g></svg><?php }
}
