<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/relationship.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80cebbf314_67905702',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8cbaffe34919c1f7a131b9c4fe639539017d673' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/relationship.svg',
      1 => 1685198821,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80cebbf314_67905702 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M380.737 65.09c-32.434 0-63.535 12.028-87.476 33.438-23.941-21.41-55.042-33.438-87.476-33.438-59.099 0-109.188 39.263-125.583 93.072C34.456 167.77 0 208.431 0 256.992c0 28.47 12.597 57.941 37.442 87.595 26.39 32.232 73.834 69.087 128.24 102.323 21.544-13.28 45.29-29.084 63.15-42.593 18.621 13.346 42.447 28.974 64.43 42.593 73.045-44.734 134.592-93.27 169.346-135.513C495.382 272.279 512 233.572 512 196.353c0-72.379-58.884-131.263-131.263-131.263zM165.682 411.459C75.643 353.799 30 301.851 30 256.992c0-39.142 31.844-70.985 70.986-70.985 30.452-.084 48.927 17.532 64.696 37.148 17.955-23.249 38.21-37.278 64.696-37.148 39.142 0 70.986 31.844 70.986 70.985-.001 44.859-45.644 96.807-135.682 154.467zm273.93-119.328c-31.209 37.25-80.422 77.376-146.35 119.344-14.095-8.972-27.42-17.86-39.972-26.653 16.041-13.623 29.534-26.989 40.632-40.234 24.845-29.653 37.442-59.125 37.442-87.595 0-55.684-45.302-100.985-100.986-100.985-23.794 0-46.654 8.413-64.696 23.476a100.988 100.988 0 0 0-53.041-22.777c15.458-36.183 51.377-61.615 93.146-61.615 39.688.145 66.04 20.55 87.476 47.493 24.426-31.18 51.925-47.17 87.476-47.493C436.574 95.09 482 140.516 482 196.353c0 30.405-13.865 61.734-42.388 95.778z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
