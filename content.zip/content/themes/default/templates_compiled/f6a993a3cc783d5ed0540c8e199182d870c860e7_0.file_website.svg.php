<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/website.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80cec26531_69224576',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f6a993a3cc783d5ed0540c8e199182d870c860e7' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/website.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80cec26531_69224576 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M29 13H3a1 1 0 1 1 0-2h26a1 1 0 1 1 0 2zM29 21H3a1 1 0 1 1 0-2h26a1 1 0 1 1 0 2z" data-original="#3cacb6"></path><path fill="#5e72e4" d="M16 1C7.729 1 1 7.729 1 16s6.729 15 15 15 15-6.729 15-15S24.271 1 16 1zm6 15c0 7.776-3.103 13-6 13s-6-5.224-6-13 3.103-13 6-13 6 5.224 6 13zM3 16c0-5.476 3.409-10.163 8.213-12.075C9.255 6.634 8 10.987 8 16s1.254 9.366 3.213 12.075C6.41 26.163 3 21.476 3 16zm17.787 12.075C22.745 25.366 24 21.013 24 16s-1.254-9.366-3.213-12.075C25.59 5.837 29 10.524 29 16s-3.409 10.163-8.213 12.075z" data-original="#09474d" class=""></path></g></svg><?php }
}
