<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:49:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/ssl.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e810a6ec281_34981902',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b38409216ccabef0d2120b6f069278019e91b53e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/ssl.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e810a6ec281_34981902 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#6621ba"><path d="M19.356 17.002a.9.9 0 0 0-.9-.9H8.807a.9.9 0 0 0 0 1.8h9.649a.9.9 0 0 0 .9-.9zM8.807 21.528a.9.9 0 0 0 0 1.8h4.339a.9.9 0 0 0 0-1.8z" fill="#5e72e4" data-original="#6621ba"></path><path d="M17.19 29.1H5.95a2.813 2.813 0 0 1-2.81-2.81V10.331h4.217a3.207 3.207 0 0 0 3.204-3.203V2.9H23.57c1.55 0 2.81 1.261 2.81 2.81v10.02a.9.9 0 0 0 1.8 0V5.71a4.615 4.615 0 0 0-4.61-4.61H8.72a4.527 4.527 0 0 0-3.177 1.313l-2.89 2.89A4.527 4.527 0 0 0 1.34 8.48v17.81a4.615 4.615 0 0 0 4.61 4.61h11.24a.9.9 0 0 0 0-1.8zM3.927 6.576l2.89-2.89A2.708 2.708 0 0 1 8.72 2.9h.041v4.229c0 .773-.629 1.403-1.403 1.403H3.141V8.48c0-.71.286-1.404.786-1.904z" fill="#5e72e4" data-original="#6621ba"></path></g><path fill="#5e72e4" d="M30.599 20.713a1.536 1.536 0 0 0-1.441-1.374c-1.762-.098-3.105-.555-4.106-1.397a1.536 1.536 0 0 0-1.986-.001c-1.002.843-2.346 1.3-4.108 1.398a1.53 1.53 0 0 0-1.439 1.375c-.133 1.232-.116 3.115.716 5.081 1.416 3.344 4.186 4.622 5.311 5.016a1.549 1.549 0 0 0 1.029 0c1.125-.394 3.895-1.672 5.311-5.016.829-1.966.845-3.848.713-5.082zm-2.375 4.381a7.258 7.258 0 0 1-4.167 3.991 7.262 7.262 0 0 1-4.166-3.991c-.636-1.501-.689-2.954-.605-3.972 1.967-.142 3.532-.689 4.771-1.668 1.24.979 2.806 1.526 4.773 1.668.084 1.017.03 2.469-.606 3.972z" data-original="#f98a17" class=""></path></g></svg><?php }
}
