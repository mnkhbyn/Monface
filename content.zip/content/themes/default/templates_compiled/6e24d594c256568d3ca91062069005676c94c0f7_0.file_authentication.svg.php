<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:49:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/authentication.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e810a6777e6_39313692',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e24d594c256568d3ca91062069005676c94c0f7' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/authentication.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e810a6777e6_39313692 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 64 64" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 35"><path d="M43.15 31a13.16 13.16 0 0 0 2.14-7.2 13.29 13.29 0 1 0-26.58 0 13.16 13.16 0 0 0 2.14 7.2 20 20 0 0 0-8.77 16.49c0 1.79.21 4.29 1.95 5.44 2 1.31 4.55.21 7.8-1.18C24.71 50.51 28.29 49 32 49s7.29 1.53 10.17 2.76c2.23.95 4.13 1.77 5.75 1.77a3.65 3.65 0 0 0 2-.59c1.74-1.15 2-3.65 2-5.44A20 20 0 0 0 43.15 31zM32 13.5a10.29 10.29 0 1 1-10.29 10.29A10.31 10.31 0 0 1 32 13.5zm16.31 36.92c-.62.41-3-.61-5-1.44-3.13-1.33-7-3-11.35-3s-8.22 1.67-11.35 3c-1.93.83-4.34 1.85-5 1.44-.07 0-.61-.47-.61-2.94a16.94 16.94 0 0 1 7.68-14.16 13.23 13.23 0 0 0 18.48 0 16.94 16.94 0 0 1 7.68 14.16c.08 2.52-.46 2.9-.53 2.94z" fill="#5e72e4" data-original="#000000" class=""></path><g fill="#f7931e"><path d="M18.86 2.5h-9.5A6.87 6.87 0 0 0 2.5 9.36v9.5a1.5 1.5 0 0 0 3 0v-9.5A3.86 3.86 0 0 1 9.36 5.5h9.5a1.5 1.5 0 0 0 0-3zM54.64 2.5h-9.5a1.5 1.5 0 0 0 0 3h9.5a3.86 3.86 0 0 1 3.86 3.86v9.5a1.5 1.5 0 0 0 3 0v-9.5a6.87 6.87 0 0 0-6.86-6.86zM18.86 58.5h-9.5a3.86 3.86 0 0 1-3.86-3.86v-9.5a1.5 1.5 0 0 0-3 0v9.5a6.87 6.87 0 0 0 6.86 6.86h9.5a1.5 1.5 0 0 0 0-3zM60 43.64a1.5 1.5 0 0 0-1.5 1.5v9.5a3.86 3.86 0 0 1-3.86 3.86h-9.5a1.5 1.5 0 0 0 0 3h9.5a6.87 6.87 0 0 0 6.86-6.86v-9.5a1.5 1.5 0 0 0-1.5-1.5z" fill="#5e72e4" data-original="#f7931e" class=""></path></g></g></g></svg><?php }
}
