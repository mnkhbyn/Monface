<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/twitter.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8099b4be69_60886361',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e1a60eee3b3aeb1685b058d0d434f08ad6a5a6be' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/twitter.svg',
      1 => 1710330319,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8099b4be69_60886361 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0" <?php echo '?>'; ?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1227" viewBox="0 0 1200 1227" fill="none"><g clip-path="url(#clip0_1_2)"><path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="black"/></g><defs><clipPath id="clip0_1_2"><rect width="1200" height="1227" fill="white"/></clipPath></defs></svg><?php }
}
