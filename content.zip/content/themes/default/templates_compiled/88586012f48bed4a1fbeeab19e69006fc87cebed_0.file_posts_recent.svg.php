<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:54
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/posts_recent.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c62d18584_28066182',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '88586012f48bed4a1fbeeab19e69006fc87cebed' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/posts_recent.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c62d18584_28066182 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M12.5 21a9.54 9.54 0 0 1-8.89-6.16 1 1 0 0 1 1.88-.7A7.5 7.5 0 1 0 12.5 4h-.58a7.29 7.29 0 0 0-2.68.73 6.87 6.87 0 0 0-1.38.87A1 1 0 0 1 6.6 4.06a9.6 9.6 0 0 1 5.2-2h.7a9.5 9.5 0 0 1 0 19z" data-original="#232323" class=""></path><path fill="#7fbde7" d="M16 15a1 1 0 0 1-.58-.19l-3.5-2.5a1 1 0 0 1-.42-.81V8a1 1 0 0 1 2 0v3l3.08 2.2A1 1 0 0 1 16 15z" data-original="#7fbde7"></path><path fill="#5e72e4" d="M4.89 10.5a1.94 1.94 0 0 1-1-.24C2.75 9.61 2.63 7.77 2.63 7s.12-2.6 1.29-3.26c1.11-.63 2.67.14 3.29.51S9.39 5.63 9.39 7 7.72 9.45 7.21 9.75a5 5 0 0 1-2.32.75zm0-2A4.11 4.11 0 0 0 7.38 7a4 4 0 0 0-2.47-1.5 4.19 4.19 0 0 0 0 3z" data-original="#232323" class=""></path></g></g></svg><?php }
}
