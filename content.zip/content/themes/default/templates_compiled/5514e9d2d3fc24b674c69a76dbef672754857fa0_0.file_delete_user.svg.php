<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:19
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/delete_user.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c7b014150_94837861',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5514e9d2d3fc24b674c69a76dbef672754857fa0' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/delete_user.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c7b014150_94837861 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 22 22" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g fill="#000" fill-rule="evenodd" clip-rule="evenodd"><path d="M9 1.75a3.75 3.75 0 1 0 0 7.5 3.75 3.75 0 0 0 0-7.5zM3.75 5.5a5.25 5.25 0 1 1 10.5 0 5.25 5.25 0 0 1-10.5 0z" fill="#5e72e4" data-original="#000000"></path><path d="M9 10.75A7.25 7.25 0 0 0 1.75 18a.75.75 0 0 1-1.5 0A8.75 8.75 0 0 1 9 9.25a.75.75 0 0 1 0 1.5zM16 11.75a4.25 4.25 0 1 0 3.4 6.8.75.75 0 1 1 1.2.901A5.75 5.75 0 1 1 21.75 16a.75.75 0 0 1-1.5 0A4.25 4.25 0 0 0 16 11.75z" fill="#5e72e4" data-original="#000000"></path><path d="M13.702 18.298a.75.75 0 0 1 0-1.06l3.536-3.536a.75.75 0 0 1 1.06 1.06l-3.535 3.536a.75.75 0 0 1-1.06 0z" fill="#5e72e4" data-original="#000000"></path><path d="M18.298 18.298a.75.75 0 0 1-1.06 0l-3.536-3.535a.75.75 0 0 1 1.06-1.061l3.536 3.535a.75.75 0 0 1 0 1.061z" fill="#5e72e4" data-original="#000000"></path></g></g></svg><?php }
}
