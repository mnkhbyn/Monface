<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:56
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/map.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c646f21d4_19686038',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '440018c3216f89410673279fe011dbee590a725e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/map.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c646f21d4_19686038 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#549bff" d="M12 13.75c-2.068 0-3.75-1.682-3.75-3.75S9.932 6.25 12 6.25s3.75 1.682 3.75 3.75-1.682 3.75-3.75 3.75zm0-6c-1.241 0-2.25 1.009-2.25 2.25s1.009 2.25 2.25 2.25 2.25-1.009 2.25-2.25S13.241 7.75 12 7.75z" data-original="#549bff" class=""></path><path fill="#5e72e4" d="M12 21.75c-2.552 0-7.75-5.439-7.75-11.75 0-4.273 3.477-7.75 7.75-7.75s7.75 3.477 7.75 7.75c0 6.311-5.198 11.75-7.75 11.75zm0-18A6.257 6.257 0 0 0 5.75 10c0 5.638 4.719 10.25 6.25 10.25s6.25-4.612 6.25-10.25A6.257 6.257 0 0 0 12 3.75z" data-original="#112d55" class=""></path></g></svg><?php }
}
