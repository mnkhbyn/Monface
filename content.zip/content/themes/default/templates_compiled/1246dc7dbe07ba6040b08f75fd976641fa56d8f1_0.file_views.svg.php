<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:46:47
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/views.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8057ab10e8_72894685',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1246dc7dbe07ba6040b08f75fd976641fa56d8f1' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/views.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8057ab10e8_72894685 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M20.456 12.371c.218-.289.429-.597.639-.948a2.79 2.79 0 0 0-.002-2.85C19.091 5.24 15.692 3.25 12 3.25S4.909 5.24 2.905 8.577a2.79 2.79 0 0 0 .002 2.85c1.584 2.632 4.119 4.489 6.951 5.096.138.031.283.045.422.069A5.757 5.757 0 0 0 16 21.75 5.756 5.756 0 0 0 21.75 16a5.725 5.725 0 0 0-1.294-3.629zM4.195 10.657a1.288 1.288 0 0 1-.002-1.311c1.729-2.879 4.648-4.597 7.808-4.597s6.078 1.718 7.806 4.593c.24.405.24.909.002 1.312-.16.266-.312.492-.451.686a5.714 5.714 0 0 0-3.356-1.091c-.094 0-.185.01-.277.014.006-.089.027-.174.027-.264 0-2.067-1.683-3.75-3.75-3.75s-3.75 1.683-3.75 3.75c0 1.469.863 2.809 2.203 3.415.118.053.24.078.36.119a5.674 5.674 0 0 0-.483 1.548c-.05-.01-.103-.014-.154-.025-2.433-.521-4.614-2.126-5.982-4.399zm7.487 1.558a2.232 2.232 0 0 1-.612-.169 2.248 2.248 0 0 1 .931-4.297 2.26 2.26 0 0 1 2.25 2.28c0 .175-.032.35-.078.522a5.752 5.752 0 0 0-2.491 1.663zM16 20.249c-2.344 0-4.25-1.906-4.25-4.25s1.906-4.25 4.25-4.25 4.25 1.906 4.25 4.25-1.906 4.25-4.25 4.25z" data-original="#112d55"></path><path fill="#549bff" d="M15 17.75a.747.747 0 0 1-.53-.22l-1-1a.75.75 0 1 1 1.061-1.061l.565.565 2.488-1.659a.75.75 0 0 1 .832 1.248l-3 2a.744.744 0 0 1-.416.126z" data-original="#549bff"></path></g></svg><?php }
}
