<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:18
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/edit_profile.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c7ac11e98_36780232',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14404593d7bfc9c76838eff33dfbcfa1987977fb' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/edit_profile.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c7ac11e98_36780232 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#000"><path d="M12 12.75c-3.17 0-5.75-2.58-5.75-5.75S8.83 1.25 12 1.25 17.75 3.83 17.75 7s-2.58 5.75-5.75 5.75zm0-10C9.66 2.75 7.75 4.66 7.75 7s1.91 4.25 4.25 4.25S16.25 9.34 16.25 7 14.34 2.75 12 2.75zM15.82 22.75c-.38 0-.74-.14-1-.4-.31-.31-.45-.76-.38-1.23l.19-1.35c.05-.35.26-.76.51-1.02l3.54-3.54c1.42-1.42 2.67-.61 3.28 0 .52.52.79 1.08.79 1.64 0 .57-.26 1.1-.79 1.63l-3.54 3.54c-.25.25-.67.46-1.02.51l-1.35.19c-.08.02-.15.03-.23.03zm4.49-6.83c-.18 0-.34.12-.57.35l-3.54 3.54a.38.38 0 0 0-.08.17l-.18 1.25 1.25-.18c.04-.01.14-.06.17-.09l3.54-3.54c.16-.16.35-.39.35-.57 0-.15-.12-.36-.35-.58-.24-.24-.42-.35-.59-.35z" fill="#5e72e4" data-original="#000000"></path><path d="M20.92 19.22c-.07 0-.14-.01-.2-.03a3.977 3.977 0 0 1-2.74-2.74c-.11-.4.12-.81.52-.92s.81.12.92.52c.23.82.88 1.47 1.7 1.7a.749.749 0 0 1-.2 1.47zM3.41 22.75c-.41 0-.75-.34-.75-.75 0-4.27 4.19-7.75 9.34-7.75 1.09 0 2.17.16 3.18.46.4.12.62.54.5.93-.12.4-.54.62-.93.5-.88-.26-1.8-.4-2.75-.4-4.32 0-7.84 2.8-7.84 6.25 0 .42-.34.76-.75.76z" fill="#5e72e4" data-original="#000000"></path></g></g></svg><?php }
}
