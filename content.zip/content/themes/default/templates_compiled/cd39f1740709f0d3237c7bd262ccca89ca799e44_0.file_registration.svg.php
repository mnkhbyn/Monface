<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/registration.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8099778641_67202522',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd39f1740709f0d3237c7bd262ccca89ca799e44' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/registration.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8099778641_67202522 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M256 512C114.613 512 0 397.387 0 256S114.613 0 256 0s256 114.613 256 256c-.168 141.316-114.684 255.832-256 256zm0-480C132.29 32 32 132.29 32 256s100.29 224 224 224 224-100.29 224-224c-.133-123.656-100.344-223.867-224-224zm0 0" data-original="#f03d8f" class=""></path><path fill="#5e72e4" d="M160 368c-8.836 0-16-7.164-16-16 0-52.945 50.258-96 112-96 8.836 0 16 7.164 16 16s-7.164 16-16 16c-44.113 0-80 28.703-80 64 0 8.836-7.164 16-16 16zm0 0" data-original="#f03d8f" class=""></path><g fill="#7c21ff"><path d="M256 288c-46.32-2.363-82.047-41.668-80-88-2.047-46.332 33.68-85.637 80-88 46.32 2.363 82.047 41.668 80 88 2.047 46.332-33.68 85.637-80 88zm0-144c-28.617 2.406-50 27.352-48 56-2 28.648 19.383 53.594 48 56 28.617-2.406 50-27.352 48-56 2-28.648-19.383-53.594-48-56zM352 400c-8.836 0-16-7.164-16-16v-96c0-8.836 7.164-16 16-16s16 7.164 16 16v96c0 8.836-7.164 16-16 16zm0 0" fill="#5e72e4" data-original="#7c21ff" class=""></path><path d="M400 352h-96c-8.836 0-16-7.164-16-16s7.164-16 16-16h96c8.836 0 16 7.164 16 16s-7.164 16-16 16zm0 0" fill="#5e72e4" data-original="#7c21ff" class=""></path></g></g></svg><?php }
}
