<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/header-home.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c66abc171_68114700',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e7af6139989b9c340c17eb6983dc396db8a55e50' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/header-home.svg',
      1 => 1638112703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c66abc171_68114700 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg id="Layer_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m392 511.963h-272c-66.168 0-120-53.832-120-120v-168.271c0-37.191 17.655-72.86 47.226-95.415l136-103.729c42.849-32.681 102.699-32.681 145.548 0l43.226 32.94v-25.525c1.056-26.536 38.953-26.516 40 0v65.911c0 7.603-4.311 14.548-11.125 17.923-6.814 3.374-14.951 2.592-20.998-2.015l-75.355-57.423c-28.572-21.792-68.474-21.792-97.039-.005l-136 103.729c-19.713 15.035-31.483 38.814-31.483 63.609v168.271c0 44.112 35.888 80 80 80h272c44.112 0 80-35.888 80-80v-168.271c0-25.099-11.637-48.959-31.129-63.827-8.783-6.699-10.472-19.249-3.773-28.031 6.699-8.783 19.25-10.472 28.031-3.773 29.349 22.384 46.871 58.134 46.871 95.631v168.271c0 66.168-53.832 120-120 120zm-176-281c-13.807 0-25 11.193-25 25 1.321 33.17 48.691 33.145 50 0 0-13.808-11.193-25-25-25zm105 24.999c-1.321 33.17-48.691 33.145-50 0 1.321-33.17 48.691-33.144 50 0zm-80 80c-1.321 33.17-48.691 33.145-50 0 1.321-33.17 48.691-33.144 50 0zm80 0c-1.321 33.17-48.691 33.145-50 0 1.321-33.17 48.691-33.144 50 0z"/></svg><?php }
}
