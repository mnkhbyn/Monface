<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/contat_us.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d857759_21929306',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e5913b22237c164e81bf29ba0b7358a3e962f45e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/contat_us.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d857759_21929306 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="m28.121 13.708-6.169-6.169c.028.244.047.49.047.74v1.722c0 .129-.015.254-.038.376l4.106 4.106-6.081 5.212-1.766-1.739c-.567-.625-1.376-.982-2.22-.982s-1.653.358-2.182.942l-1.806 1.778-6.08-5.212 4.434-4.434A5.971 5.971 0 0 1 10 8c0-.147.012-.292.022-.436l-6.143 6.143A2.98 2.98 0 0 0 3 15.829V27c0 1.654 1.346 3 3 3h20c1.654 0 3-1.346 3-3V15.829c0-.801-.312-1.555-.879-2.122zM5 26.598v-10.28l5.582 4.784L5 26.597zm1.425 1.403 8.835-8.7c.384-.422 1.057-.462 1.518.04l8.796 8.66zM27 26.598l-5.583-5.495L27 16.318z" data-original="#06474d"></path><path fill="#3cacb6" d="M16.184 1.003c-1.917-.067-3.706.655-5.069 1.984A6.946 6.946 0 0 0 9 8.001c0 3.86 3.14 7 7 7a1 1 0 0 0 0-2c-2.757 0-5-2.243-5-5 0-1.36.537-2.632 1.511-3.582a5.035 5.035 0 0 1 3.622-1.417c2.684.069 4.868 2.436 4.868 5.276V10c0 .551-.449 1-1 1s-1-.449-1-1V8c0-1.654-1.346-3-3-3s-3 1.346-3 3 1.346 3 3 3c.395 0 .77-.081 1.116-.22A2.995 2.995 0 0 0 20.001 13c1.654 0 3-1.346 3-3V8.278c0-3.915-3.058-7.179-6.816-7.275zM16 9.001c-.551 0-1-.449-1-1s.449-1 1-1 1 .449 1 1-.449 1-1 1z" data-original="#3cacb6" class=""></path></g></svg><?php }
}
