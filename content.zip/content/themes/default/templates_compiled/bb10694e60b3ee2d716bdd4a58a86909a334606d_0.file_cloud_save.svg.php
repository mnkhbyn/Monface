<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:21
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/cloud_save.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e812d78d958_40337087',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bb10694e60b3ee2d716bdd4a58a86909a334606d' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/cloud_save.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e812d78d958_40337087 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 200 200" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#00a5ec"><path d="M105 66a7 7 0 0 0-9.9 0L69.85 91.23a7 7 0 1 0 9.9 9.9L93 87.89v46.62a7 7 0 0 0 14 0V87.89l13.25 13.24a7 7 0 1 0 9.9-9.9z" fill="#5e72e4" data-original="#00a5ec"></path><path d="M163.54 83.39a65.69 65.69 0 0 0-127.11 0 41.29 41.29 0 0 0 4.86 82.3h117.38a41.29 41.29 0 0 0 4.87-82.3zm-4.87 68.3H41.29a27.3 27.3 0 0 1 0-54.59h.86a7 7 0 0 0 6.9-5.83 51.68 51.68 0 0 1 101.87 0 7 7 0 0 0 6.9 5.83h.85a27.3 27.3 0 1 1 0 54.59z" fill="#5e72e4" data-original="#00a5ec"></path></g></g></svg><?php }
}
