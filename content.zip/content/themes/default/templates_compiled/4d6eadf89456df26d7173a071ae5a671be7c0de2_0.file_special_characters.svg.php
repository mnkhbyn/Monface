<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:48:46
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/special_characters.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80ceb05aa1_81405693',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d6eadf89456df26d7173a071ae5a671be7c0de2' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/special_characters.svg',
      1 => 1685361856,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80ceb05aa1_81405693 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg fill="none" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg"><g clip-rule="evenodd" fill="rgb(0,0,0)" fill-rule="evenodd"><path d="m22 11.5c.5682 0 1.0876.321 1.3417.8292l7 14c.3704.7409.0701 1.642-.6709 2.0124-.7409.3705-1.6419.0702-2.0124-.6708l-5.6584-11.3167-5.6583 11.3167c-.3705.741-1.2715 1.0413-2.0125.6708-.741-.3704-1.0413-1.2715-.6708-2.0124l7-14c.2541-.5082.7735-.8292 1.3416-.8292z"/><path d="m15.5 23c0-.8284.6716-1.5 1.5-1.5h10c.8284 0 1.5.6716 1.5 1.5s-.6716 1.5-1.5 1.5h-10c-.8284 0-1.5-.6716-1.5-1.5z"/><path d="m11 2.5c.8284 0 1.5.67157 1.5 1.5v3c0 .82843-.6716 1.5-1.5 1.5s-1.5-.67157-1.5-1.5v-3c0-.82843.6716-1.5 1.5-1.5z"/><path d="m1.5 7c0-.82843.67157-1.5 1.5-1.5h16c.8284 0 1.5.67157 1.5 1.5s-.6716 1.5-1.5 1.5h-16c-.82843 0-1.5-.67157-1.5-1.5z"/><path d="m15 5.5c.8284 0 1.5.67157 1.5 1.5 0 3.5804-1.4223 7.0142-3.9541 9.5459-2.5317 2.5318-5.96548 3.9541-9.5459 3.9541-.82843 0-1.5-.6716-1.5-1.5s.67157-1.5 1.5-1.5c2.78477 0 5.45549-1.1062 7.4246-3.0754 1.9692-1.9691 3.0754-4.63983 3.0754-7.4246 0-.82843.6716-1.5 1.5-1.5z"/><path d="m7.46161 10.6368c.75286-.3457 1.6434-.0156 1.98908.7373.83911 1.8276 2.18491 3.3761 3.87761 4.4619 1.6926 1.0858 3.6612 1.6633 5.6723 1.664.8284.0003 1.4997.6721 1.4994 1.5005-.0003.8285-.6721 1.4998-1.5005 1.4995-2.5849-.0009-5.1153-.7432-7.291-2.1389-2.17577-1.3956-3.90554-3.3861-4.98415-5.7352-.34568-.7529-.0156-1.6434.73726-1.9891z"/></g></svg><?php }
}
