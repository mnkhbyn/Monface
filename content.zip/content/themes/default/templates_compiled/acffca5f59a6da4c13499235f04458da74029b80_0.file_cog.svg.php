<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/cog.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c6611bb96_02227639',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'acffca5f59a6da4c13499235f04458da74029b80' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/cog.svg',
      1 => 1685287381,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c6611bb96_02227639 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#000" fill-rule="evenodd" clip-rule="evenodd"><path d="M9.332 3.803c.988-2.371 4.348-2.371 5.336 0a.895.895 0 0 0 1.2.464c2.454-1.133 4.997 1.41 3.864 3.865a.895.895 0 0 0 .464 1.2c2.372.988 2.372 4.348 0 5.336a.895.895 0 0 0-.464 1.2c1.133 2.454-1.41 4.997-3.864 3.864a.895.895 0 0 0-1.2.464c-.988 2.372-4.348 2.372-5.336 0a.895.895 0 0 0-1.2-.464c-2.454 1.133-4.998-1.41-3.865-3.864a.895.895 0 0 0-.464-1.2c-2.371-.988-2.371-4.348 0-5.336a.894.894 0 0 0 .464-1.2c-1.133-2.454 1.41-4.998 3.865-3.865a.894.894 0 0 0 1.2-.464zm3.49.77c-.304-.731-1.34-.731-1.644 0a2.894 2.894 0 0 1-3.884 1.51c-.766-.353-1.564.445-1.21 1.211a2.894 2.894 0 0 1-1.511 3.884c-.731.304-.731 1.34 0 1.644a2.894 2.894 0 0 1 1.51 3.884c-.353.766.445 1.564 1.211 1.21a2.894 2.894 0 0 1 3.884 1.511c.304.73 1.34.73 1.644 0a2.894 2.894 0 0 1 3.884-1.51c.766.353 1.564-.445 1.21-1.211a2.894 2.894 0 0 1 1.511-3.884c.73-.304.73-1.34 0-1.644a2.894 2.894 0 0 1-1.51-3.884c.353-.766-.445-1.564-1.211-1.21a2.894 2.894 0 0 1-3.884-1.511z" fill="#5e72e4" data-original="#000000"></path><path d="M12 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0z" fill="#5e72e4" data-original="#000000"></path></g></g></svg><?php }
}
