<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:52
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/social_share.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c9ce1cf12_40725211',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e38cf0c18672f300d1b77494f0e3882171d88566' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/social_share.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c9ce1cf12_40725211 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#7fbde7" d="M18 10a4 4 0 1 1 4-4 4 4 0 0 1-4 4zm0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2z" data-original="#7fbde7"></path><g fill="#232323"><path d="M18 22a4 4 0 1 1 4-4 4 4 0 0 1-4 4zm0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2zM6 16a4 4 0 1 1 4-4 4 4 0 0 1-4 4zm0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2z" fill="#5e72e4" data-original="#232323" class=""></path><path d="M15.32 17.66a.93.93 0 0 1-.45-.11l-6.64-3.32a1 1 0 1 1 .9-1.78l6.64 3.32a1 1 0 0 1 .44 1.34 1 1 0 0 1-.89.55zM8.68 11.66a1 1 0 0 1-.89-.55 1 1 0 0 1 .44-1.34l3.95-2a1 1 0 1 1 .9 1.78l-3.95 2a.93.93 0 0 1-.45.11z" fill="#5e72e4" data-original="#232323" class=""></path></g></g></g></svg><?php }
}
