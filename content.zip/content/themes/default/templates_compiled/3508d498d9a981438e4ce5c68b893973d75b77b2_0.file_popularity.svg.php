<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:54
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/popularity.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c62d8a267_49718875',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3508d498d9a981438e4ce5c68b893973d75b77b2' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/popularity.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c62d8a267_49718875 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 48 48" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#232323"><path d="M43 45h-8a2.002 2.002 0 0 1-2-2V27a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v16a2.002 2.002 0 0 1-2 2zm-8-18v16h8V27zM28 45h-8a2.002 2.002 0 0 1-2-2V23a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v20a2.002 2.002 0 0 1-2 2zm-8-22v20h8V23zM13 45H5a2.002 2.002 0 0 1-2-2V30a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v13a2.002 2.002 0 0 1-2 2zM5 30v13h8V30z" fill="#5e72e4" data-original="#232323"></path></g><path fill="#7fbde7" d="M28.593 18.999a1.478 1.478 0 0 1-.733-.195L24 16.598l-3.86 2.206a1.479 1.479 0 0 1-2.168-1.642l1.113-4.454-2.589-2.59a1.479 1.479 0 0 1 1.046-2.525h3.514l1.585-3.697a1.479 1.479 0 0 1 2.718 0l1.585 3.697h3.514a1.479 1.479 0 0 1 1.045 2.525l-2.588 2.59 1.113 4.453A1.48 1.48 0 0 1 28.593 19zM24 14.52a1.477 1.477 0 0 1 .733.194l3.058 1.747-.888-3.555a1.483 1.483 0 0 1 .39-1.406L29.2 9.593h-2.6a1.477 1.477 0 0 1-1.36-.897L24 5.802l-1.241 2.895a1.476 1.476 0 0 1-1.36.896h-2.6l1.909 1.909a1.483 1.483 0 0 1 .389 1.406l-.889 3.553 3.059-1.747A1.477 1.477 0 0 1 24 14.52zm-4.706-1.604.001.001zm9.414-.001-.002.001zM20.92 7.909l-.001.002zm6.158-.001v.001z" data-original="#7fbde7"></path></g></svg><?php }
}
