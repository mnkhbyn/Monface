<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/sunrise.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c66491ea5_62847366',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '59571beb70ad95c3e560f82a77904abd64ea4dff' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/sunrise.svg',
      1 => 1685094670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c66491ea5_62847366 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="m16.416 14.867-1.455-.364.182-.728A3.254 3.254 0 0 0 12 9.697a3.254 3.254 0 0 0-3.143 4.078l.182.728-1.455.364-.182-.728a4.926 4.926 0 0 1-.152-1.192c0-2.619 2.131-4.75 4.75-4.75s4.75 2.131 4.75 4.75c0 .387-.051.788-.152 1.192z" data-original="#4c5dff"></path><path fill="#df4cff" d="M9.36 7.536a.75.75 0 0 1-.69-.455l-.511-1.192a.75.75 0 0 1 1.379-.591l.511 1.192a.75.75 0 0 1-.689 1.046zm5.825-.534.482-1.205a.75.75 0 0 0-1.392-.558l-.482 1.205a.75.75 0 0 0 1.392.558zm3.271 3.994 1.192-.511a.75.75 0 1 0-.591-1.379l-1.192.511a.75.75 0 1 0 .591 1.379zm-11.983-.259a.75.75 0 0 0-.417-.975L4.851 9.28a.75.75 0 0 0-.558 1.392l1.205.482a.75.75 0 0 0 .975-.417z" data-original="#df4cff"></path><g fill="#4c5dff"><path d="M21 15.746H3a.75.75 0 0 1 0-1.5h18a.75.75 0 0 1 0 1.5zM19 18.231H5a.75.75 0 0 1 0-1.5h14a.75.75 0 0 1 0 1.5z" fill="#5e72e4" data-original="#4c5dff"></path></g></g></svg><?php }
}
