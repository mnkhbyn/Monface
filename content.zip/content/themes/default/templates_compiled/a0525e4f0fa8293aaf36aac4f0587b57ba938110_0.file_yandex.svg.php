<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/yandex.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135e2ca59_53105837',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a0525e4f0fa8293aaf36aac4f0587b57ba938110' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/yandex.svg',
      1 => 1716817646,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135e2ca59_53105837 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg width='100' height='100' viewBox='0 0 100 100' fill='none' xmlns='http://www.w3.org/2000/svg'><rect width='100' height='100' fill='white'/><g clip-path='url(#clip0)'><path d='M100 0H0V100H100V0Z' fill='white'/><path fill-rule='evenodd' clip-rule='evenodd' d='M7.40016 100C6.70016 97.8 6.50016 95.5 6.90016 93.5L17.0002 38.1C18.1002 31.9 24.1002 20.7 40.4002 16.9C43.2002 16.3 45.8002 15.6 48.2002 15C57.7002 12.6 64.1002 10.9 66.6002 14C66.6002 14 66.6002 14 66.7002 14.1C67.2002 14.7 69.1002 17 67.6002 24.4C65.6002 34.7 65.5002 35.1 65.5002 35.1C49.2002 38.4 41.5002 40.5 39.5002 50.2L36.3002 65.2C37.4002 65.7 36.7002 69.3 35.9002 73.3C35.2002 77 34.4002 80.9 35.0002 82.7C36.3002 85.7 39.8002 86.2 42.3002 85.7C44.0002 85.3 45.8002 84.8 48.2002 84.1C51.3002 83.2 55.5002 81.9 62.0002 80.2C67.7002 78.9 76.0002 74.8 79.8002 65.3L99.0002 76.5C98.8002 77.5 98.7001 78.7 98.5002 80.2C97.8002 85.6 96.8002 93.5 94.0002 100H7.40016Z' fill='url(#paint0_radial)'/><path d='M81.6 57C80.3 72.6 69.1 78.5 62 80.2V100C83.4 100 61.7 99.9 83.4 100C99.7 99.9 83.4 100 100 100V19.6C100 5.10001 100 5.1 100 0C89 0 88.3 0 75.5 0C81.1 0 90.6 2.70001 89.8 8.50001L87.1 25.8L81.6 57Z' fill='url(#paint1_radial)'/><path d='M77.4999 0C64.9999 3.22238e-06 75.2999 3.22238e-06 63.9999 3.22238e-06C16.4999 3.22238e-06 64.2999 3.22238e-06 16.6999 3.22238e-06C2.4999 3.5 1.7999 15.5 0.399902 23.5L24.7999 26.9C29.0999 22.4 34.3999 20 38.2999 19C49.6999 16.2 56.0999 14.8 60.0999 13.9C61.8999 13.5 64.7999 13.8 66.0999 16.5C67.3999 19.2 66.2999 23.8 64.0999 35.1L60.9999 49.9C58.7999 59.7 52.5999 61.9 36.2999 65.3C36.2999 65.3 36.1999 65.2 34.2999 75.5C32.7999 83.3 34.6999 84.6 34.9999 85C38.3999 88.7 46.3999 85.5 60.0999 82.4C76.3999 78.6 81.4999 67.4 82.6999 61.2L90.4999 14.7C91.3999 8.1 92.4999 0 77.4999 0Z' fill='url(#paint2_radial)'/><path fill-rule='evenodd' clip-rule='evenodd' d='M18.1 100C18.1 100 18 100 17.9 100C15.6 99.7 8 98.6 9.5 85.8L17.8 40.7C20.4 27.1 31.4 20.7 38.4 19V0.1V0H0V100H18.1Z' fill='url(#paint3_radial)'/></g><defs><radialGradient id='paint0_radial' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='translate(70.078 95.2955) rotate(-112.141) scale(82.2845 192.881)'><stop offset='0.1946' stop-color='#B3C8FF'/><stop offset='0.3501' stop-color='#9EB9FF'/><stop offset='0.5946' stop-color='#6F97FF'/><stop offset='0.7651' stop-color='#5282FF'/></radialGradient><radialGradient id='paint1_radial' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='translate(72.4336 81.1615) rotate(-98.2463) scale(65.1881 99.3985)'><stop offset='0.2314' stop-color='#B3C8FF'/><stop offset='0.5767' stop-color='#C1D3FF'/><stop offset='1' stop-color='#CAD9FF'/></radialGradient><radialGradient id='paint2_radial' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='translate(39.0958 11.381) rotate(69.495) scale(74.2427 139.227)'><stop offset='0.1701' stop-color='#B3C8FF'/><stop offset='0.3103' stop-color='#9EB9FF'/><stop offset='0.5291' stop-color='#6F97FF'/><stop offset='0.744' stop-color='#5282FF'/></radialGradient><radialGradient id='paint3_radial' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='translate(37.7515 8.56883) rotate(69.6638) scale(94.3934 143.926)'><stop offset='0.2314' stop-color='#B3C8FF'/><stop offset='0.5767' stop-color='#C1D3FF'/><stop offset='1' stop-color='#CAD9FF'/></radialGradient><clipPath id='clip0'><rect width='100' height='100' rx='21.88' fill='white'/></clipPath></defs></svg>
<?php }
}
