<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:10
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/chat_seen.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e81227b9977_87398946',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc65973d7937bbf814ff36f170ae3c29260019cb' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/chat_seen.svg',
      1 => 1685361900,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e81227b9977_87398946 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg id="Icons" height="512" viewBox="0 0 24 24" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m20.243 3.831a1 1 0 0 0 -1.412-.074l-9.295 8.365-4.329-4.329a1 1 0 1 0 -1.414 1.414l5 5a1 1 0 0 0 1.376.036l10-9a1 1 0 0 0 .074-1.412z"/><path d="m18.831 9.757-9.295 8.365-4.329-4.329a1 1 0 0 0 -1.414 1.414l5 5a1 1 0 0 0 1.376.036l10-9a1 1 0 0 0 -1.338-1.486z"/></svg><?php }
}
