<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:50
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/bank.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e814a6e6743_16673805',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b777b0d1d32ae3513497a90f0455107deb89d93c' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/bank.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e814a6e6743_16673805 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#3cacb6"><path d="M6 12a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V13a1 1 0 0 0-1-1zM11 12a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V13a1 1 0 0 0-1-1zM16 12a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V13a1 1 0 0 0-1-1zM21 12a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V13a1 1 0 0 0-1-1zM26 12a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V13a1 1 0 0 0-1-1z" fill="#5e72e4" data-original="#3cacb6"></path></g><path fill="#5e72e4" d="M28 14H4c-1.103 0-2-.897-2-2v-1.403c0-.737.403-1.412 1.053-1.761L15.526 2.12a1 1 0 0 1 .947 0l12.474 6.717A1.997 1.997 0 0 1 30 10.598v1.403c0 1.103-.897 2-2 2zM16 4.136 4 10.597V12h24.001v-1.403L16 4.136zM28 30H4c-1.103 0-2-.897-2-2v-2c0-1.103.897-2 2-2h24c1.103 0 2 .897 2 2v2c0 1.103-.897 2-2 2zM4 26v2h24.001v-2z" data-original="#0c474d" class=""></path></g></svg><?php }
}
