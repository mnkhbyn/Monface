<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:46:47
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/right_click.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8057c4be82_28351733',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b2dcc0f07f34b6f5dca0f702e1e63a60acc41b1f' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/right_click.svg',
      1 => 1719402081,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8057c4be82_28351733 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0" encoding="utf-8"<?php echo '?>'; ?>


<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
<svg version="1.1" id="_x32_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 512 512"  xml:space="preserve">
<style type="text/css">
	.st0 { fill:#000000; }
</style>
<g>
	<path class="st0" d="M246.086,115.746h-88.671c-30.282-0.007-57.904,12.335-77.725,32.202
		c-19.859,19.813-32.208,47.427-32.193,77.724v124.134c0,44.374,16.991,84.84,44.752,114.251
		c27.699,29.418,66.6,47.959,109.502,47.943c42.901,0.016,81.802-18.525,109.502-47.943c27.761-29.411,44.76-69.877,44.76-114.251
		V225.672c0.008-30.298-12.343-57.912-32.202-77.732C303.983,128.081,276.368,115.739,246.086,115.746z M89.983,225.672
		c0.015-18.694,7.516-35.416,19.75-47.689c12.265-12.234,28.995-19.736,47.682-19.751h43.819v101.199H89.983V225.672z
		 M313.526,349.806c0,33.466-12.79,63.478-33.172,85.087c-20.438,21.601-48.044,34.607-78.603,34.622
		c-30.559-0.015-58.158-13.021-78.604-34.622c-20.375-21.609-33.164-51.613-33.164-85.087v-60.031h223.544V349.806z"/>
	<rect x="271.033" y="0" class="st0" width="24.284" height="69.799"/>
	<polygon class="st0" points="237.93,78.672 203.03,18.217 181.999,30.359 216.899,90.808 	"/>
	<polygon class="st0" points="394.704,169.187 394.704,193.463 464.496,193.463 464.503,169.179 	"/>
	<polygon class="st0" points="434.137,80.146 373.689,115.045 385.831,136.076 446.272,101.176 	"/>
	<polygon class="st0" points="384.343,30.367 363.321,18.217 328.421,78.672 349.451,90.808 	"/>
</g>
</svg><?php }
}
