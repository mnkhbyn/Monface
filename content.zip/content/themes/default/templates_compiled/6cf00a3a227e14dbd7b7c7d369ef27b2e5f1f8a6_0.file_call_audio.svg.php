<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/call_audio.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c663b5ca3_80881817',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6cf00a3a227e14dbd7b7c7d369ef27b2e5f1f8a6' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/call_audio.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c663b5ca3_80881817 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g data-name="Layer 2"><path fill="#5e72e4" d="M14.766 22.732a10.087 10.087 0 0 1-5.456-1.59 22.51 22.51 0 0 1-3.597-2.783 22.217 22.217 0 0 1-2.781-3.464 10.135 10.135 0 0 1-.426-10.506l.348-.64a2.599 2.599 0 0 1 4.122-.598L9.435 5.61a2.6 2.6 0 0 1-.77 4.208l-1.283.579a.48.48 0 0 0-.257.601 9.358 9.358 0 0 0 2.237 3.695 9.387 9.387 0 0 0 3.718 2.175.487.487 0 0 0 .597-.258l.562-1.233a2.6 2.6 0 0 1 4.203-.758l2.435 2.434a2.599 2.599 0 0 1-.64 4.145l-.717.373a10.313 10.313 0 0 1-4.754 1.162zM5.142 3.89a1.117 1.117 0 0 0-.162.011 1.088 1.088 0 0 0-.808.564l-.348.64a8.64 8.64 0 0 0 .354 8.955 21.222 21.222 0 0 0 2.586 3.23 21.45 21.45 0 0 0 3.356 2.59 8.716 8.716 0 0 0 8.708.36l.718-.374a1.1 1.1 0 0 0 .27-1.753l-2.434-2.435a1.099 1.099 0 0 0-1.778.321l-.563 1.234a1.985 1.985 0 0 1-2.436 1.057 10.836 10.836 0 0 1-4.295-2.53 10.807 10.807 0 0 1-2.601-4.269A1.97 1.97 0 0 1 6.765 9.03l1.283-.579a1.1 1.1 0 0 0 .326-1.78L5.915 4.212a1.088 1.088 0 0 0-.773-.322z" data-original="#232323"></path><g fill="#7fbde7"><path d="M17.555 11.64a.75.75 0 0 1-.742-.644 4.486 4.486 0 0 0-3.807-3.808.75.75 0 0 1 .21-1.485 5.988 5.988 0 0 1 5.082 5.08.75.75 0 0 1-.637.85.779.779 0 0 1-.106.007zM21.999 11.64a.75.75 0 0 1-.741-.644 9.725 9.725 0 0 0-8.252-8.252.75.75 0 0 1 .21-1.486 11.225 11.225 0 0 1 9.526 9.526.75.75 0 0 1-.636.848.804.804 0 0 1-.107.008z" fill="#7fbde7" data-original="#7fbde7"></path></g></g></g></svg><?php }
}
