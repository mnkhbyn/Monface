<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/call_video.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c663364a8_66747997',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5fd51072d4b547b4a0115279fee69d2443d69cab' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/call_video.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c663364a8_66747997 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M19.51 18.07c-.38 0-.77-.09-1.12-.27l-2.83-1.42a.998.998 0 0 1 .9-1.78l2.83 1.42a.503.503 0 0 0 .73-.44V8.44a.503.503 0 0 0-.73-.45l-2.83 1.42a.998.998 0 0 1-.9-1.78l2.83-1.42c.78-.39 1.69-.35 2.43.11s1.19 1.26 1.19 2.13v7.14c0 .86-.46 1.68-1.19 2.13-.4.25-.86.37-1.31.37z" data-original="#ff38ac"></path><path fill="#5e72e4" d="M14.01 20H4.99c-1.65 0-3-1.35-3-3V7c0-1.65 1.35-3 3-3h9.02c1.65 0 3 1.35 3 3v10c0 1.65-1.35 3-3 3zM4.99 6c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h9.02c.55 0 1-.45 1-1V7c0-.55-.45-1-1-1z" data-original="#3c36b5" class=""></path></g></svg><?php }
}
