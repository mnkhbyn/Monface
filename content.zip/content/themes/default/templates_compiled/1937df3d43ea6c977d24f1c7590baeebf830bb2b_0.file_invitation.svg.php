<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/invitation.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80997ee2d0_51456408',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1937df3d43ea6c977d24f1c7590baeebf830bb2b' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/invitation.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80997ee2d0_51456408 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M19 20h-2a1 1 0 0 1 0-2h2a1 1 0 0 0 1-1V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h5a1 1 0 0 1 0 2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h12a4 4 0 0 1 4 4v9a3 3 0 0 1-3 3z" data-original="#232323"></path><path fill="#5e72e4" d="M14.5 20h-1a1 1 0 0 1 0-2h1a1 1 0 0 1 0 2z" data-original="#232323"></path><path fill="#5e72e4" d="M12 13.64a4 4 0 0 1-1.79-.42l-4.66-2.33a1 1 0 1 1 .9-1.78l4.66 2.32a1.93 1.93 0 0 0 1.78 0l4.66-2.32a1 1 0 1 1 .9 1.78l-4.66 2.33a4 4 0 0 1-1.79.42z" data-original="#7fbde7" class=""></path></g></g></svg><?php }
}
