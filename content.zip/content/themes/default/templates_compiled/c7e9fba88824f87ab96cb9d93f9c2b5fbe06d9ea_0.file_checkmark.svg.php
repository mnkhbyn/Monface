<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:38
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/checkmark.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c5285b260_16347939',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c7e9fba88824f87ab96cb9d93f9c2b5fbe06d9ea' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/checkmark.svg',
      1 => 1684870075,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c5285b260_16347939 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 511" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M512 256.5c0 50.531-15 99.672-43.375 142.113-3.855 5.77-10.191 8.887-16.645 8.887-3.82 0-7.683-1.09-11.097-3.375-9.184-6.137-11.649-18.559-5.512-27.742C459.336 340.543 472 299.09 472 256.5c0-18.3-2.29-36.477-6.805-54.016-2.754-10.695 3.688-21.601 14.383-24.355 10.703-2.75 21.602 3.687 24.356 14.383C509.285 213.309 512 234.836 512 256.5zM367.734 441.395C334.141 461.742 295.504 472.5 256 472.5c-119.102 0-216-96.898-216-216s96.898-216 216-216c44.098 0 86.5 13.195 122.629 38.16 9.086 6.278 21.543 4 27.824-5.086 6.277-9.086 4.004-21.543-5.086-27.824C358.523 16.148 308.257.5 256 .5 187.621.5 123.332 27.129 74.98 75.48 26.63 123.832 0 188.121 0 256.5s26.629 132.668 74.98 181.02C123.332 485.87 187.621 512.5 256 512.5c46.813 0 92.617-12.758 132.46-36.895 9.45-5.722 12.47-18.02 6.747-27.468-5.727-9.45-18.023-12.465-27.473-6.742zM257.93 314.492c-3.168.125-6.125-1-8.422-3.187l-104.746-99.317c-8.016-7.601-20.676-7.265-28.274.75-7.601 8.016-7.265 20.676.75 28.274l104.727 99.3c9.672 9.196 22.183 14.188 35.441 14.188.711 0 1.422-.016 2.133-.043 14.043-.566 26.941-6.644 36.316-17.117.239-.262.465-.531.688-.809l211.043-262.5c6.922-8.61 5.555-21.199-3.055-28.117-8.605-6.922-21.199-5.555-28.12 3.055L265.78 310.957a11.434 11.434 0 0 1-7.851 3.535zm0 0" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
