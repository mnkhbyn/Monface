<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:30:52
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/appgallery.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c9cf0fa78_87806387',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '04630aea04ae678a4d0e359cd965bbd0c6178134' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/appgallery.svg',
      1 => 1638112703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c9cf0fa78_87806387 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0" encoding="UTF-8" standalone="no"<?php echo '?>'; ?>

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="100"
   height="100"
   viewBox="0 0 80 80"
   version="1.1"
   id="svg2"
   sodipodi:version="0.32"
   inkscape:version="0.92.4 (5da689c313, 2019-01-14)"
   sodipodi:docname="Huawei AppGallery.svg">
  <title
     id="title854">Huawei AppGallery </title>
  <metadata
     id="metadata59">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title>Huawei AppGallery </dc:title>
        <cc:license
           rdf:resource="http://scripts.sil.org/OFL" />
        <dc:date>23 jul 2020</dc:date>
        <dc:creator>
          <cc:Agent>
            <dc:title>EEIM</dc:title>
          </cc:Agent>
        </dc:creator>
        <dc:rights>
          <cc:Agent>
            <dc:title>N/A</dc:title>
          </cc:Agent>
        </dc:rights>
        <dc:language>es</dc:language>
      </cc:Work>
      <cc:License
         rdf:about="http://scripts.sil.org/OFL">
        <cc:permits
           rdf:resource="http://scripts.sil.org/pub/OFL/Reproduction" />
        <cc:permits
           rdf:resource="http://scripts.sil.org/pub/OFL/Distribution" />
        <cc:permits
           rdf:resource="http://scripts.sil.org/pub/OFL/Embedding" />
        <cc:permits
           rdf:resource="http://scripts.sil.org/pub/OFL/DerivativeWorks" />
        <cc:requires
           rdf:resource="http://scripts.sil.org/pub/OFL/Notice" />
        <cc:requires
           rdf:resource="http://scripts.sil.org/pub/OFL/Attribution" />
        <cc:requires
           rdf:resource="http://scripts.sil.org/pub/OFL/ShareAlike" />
        <cc:requires
           rdf:resource="http://scripts.sil.org/pub/OFL/DerivativeRenaming" />
        <cc:requires
           rdf:resource="http://scripts.sil.org/pub/OFL/BundlingWhenSelling" />
      </cc:License>
    </rdf:RDF>
  </metadata>
  <defs
     id="defs57">
    <pattern
       y="0"
       x="0"
       height="6"
       width="6"
       patternUnits="userSpaceOnUse"
       id="EMFhbasepattern" />
  </defs>
  <sodipodi:namedview
     inkscape:window-height="705"
     inkscape:window-width="1366"
     inkscape:pageshadow="2"
     inkscape:pageopacity="0"
     guidetolerance="1"
     gridtolerance="1"
     objecttolerance="1"
     borderopacity="1.0"
     bordercolor="#666666"
     pagecolor="#ffffff"
     id="base"
     inkscape:zoom="3.8047958"
     inkscape:cx="49.440764"
     inkscape:cy="60.131139"
     inkscape:window-x="-8"
     inkscape:window-y="-8"
     inkscape:current-layer="svg2"
     showgrid="false"
     showguides="false"
     inkscape:showpageshadow="false"
     units="px"
     inkscape:window-maximized="1" />
  <g
     id="#ffffffff"
     transform="translate(0,-1061)" />
  <g
     id="#2acbffff-4"
     transform="matrix(0.74035173,0,0,0.75447038,-840.95699,-747.15387)"
     style="fill:#00ff00" />
  <rect
     style="opacity:1;fill:#e14459;fill-opacity:1;stroke:none;stroke-width:0;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
     id="rect817"
     width="79.199997"
     height="79.199997"
     x="0.53971732"
     y="0.41223329"
     ry="17.05821" />
  <path
     inkscape:connector-curvature="0"
     style="opacity:1;fill:#c73148;fill-opacity:1;stroke:none;stroke-width:0;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
     d="m 19.846101,5.5892037 a 2.2531937,2.2451057 0 0 0 -2.250188,2.24728 2.2531937,2.2451057 0 0 0 2.254223,2.2429633 2.2531937,2.2451057 0 0 0 2.252206,-2.2449813 v -0.0045 a 2.2531937,2.2451057 0 0 0 -2.256241,-2.24094 z m 40.302329,0 a 2.2531937,2.2451057 0 0 0 -2.250165,2.24728 2.2531937,2.2451057 0 0 0 2.254519,2.2429633 2.2531937,2.2451057 0 0 0 2.25191,-2.2449813 v -0.0045 a 2.2531937,2.2451057 0 0 0 -2.256264,-2.24094 z"
     id="path838" />
  <path
     style="fill:#ffffff;stroke-width:1.07878268"
     d="m 19.756854,7.5248907 c -0.783045,0.04202 -0.743385,1.180905 -0.743385,1.180905 4.208191,8.1949343 11.956813,12.2145273 20.892347,12.2149513 8.923732,-0.01302 16.74923,-4.07695 20.951862,-12.2610733 0,0 0.166594,-1.541107 -1.473514,-1.00693 -4.309914,7.1438013 -11.550732,11.3699843 -19.47307,11.3833033 -7.937347,0.002 -15.152249,-4.179801 -19.4704,-11.3371733 -0.278896,-0.134618 -0.503147,-0.183672 -0.68384,-0.173983 z M 48.237616,39.378914 45.84349,46.509142 43.512876,39.384194 H 41.23778 l 3.67319,10.364525 h 1.771129 l 2.399398,-6.808642 2.396773,6.808642 h 1.785661 l 3.665287,-10.364525 h -2.218212 l -2.334619,7.124948 -2.394104,-7.130228 z m -12.71662,0.0026 -4.645384,10.361891 h 2.183809 l 0.896805,-2.005967 0.06348,-0.151556 h 4.826593 l 0.945755,2.157523 H 42.03537 L 37.43233,39.44214 37.3913,39.38152 Z m 33.642014,0.0013 V 49.73682 h 2.111065 V 39.382885 Z m -60.5288956,0.0013 V 49.752591 H 10.774267 V 45.54175 h 4.830559 v 4.210915 h 2.140168 V 39.384206 h -2.140168 v 4.183231 h -4.830559 v -4.183231 z m 19.0140566,0.0026 v 5.934819 c 0,1.685887 -0.850843,2.585871 -2.396751,2.585871 -1.554607,0 -2.411328,-0.925148 -2.411328,-2.657035 v -5.856924 h -2.138833 v 5.928225 c 0,2.917151 1.649224,4.589177 4.522386,4.589177 2.900445,0 4.563366,-1.7042 4.563366,-4.674841 v -5.849155 z m 31.005843,0.0039 V 49.74468 h 7.96277 v -1.887322 h -5.853017 v -2.567434 h 3.891426 v -1.8885 H 60.763767 V 41.279495 H 66.41308 V 39.39084 Z m -22.22696,2.614853 1.526431,3.471534 0.103164,0.238555 h -3.235375 l 0.101853,-0.238555 z"
     id="path2"
     inkscape:connector-curvature="0" />
</svg>
<?php }
}
