<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:51:15
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/censored.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8163cdf975_08599001',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e71c987db653335c07b81183b7730255353d8448' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/censored.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8163cdf975_08599001 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="07. Spam"><path d="M15 22.24H9a3 3 0 0 1-2.12-.88l-4.24-4.24A3 3 0 0 1 1.76 15V9a3 3 0 0 1 .88-2.12l4.24-4.24A3 3 0 0 1 9 1.76h6a3 3 0 0 1 2.12.88l4.24 4.24A3 3 0 0 1 22.24 9v6a3 3 0 0 1-.88 2.12l-4.24 4.24a3 3 0 0 1-2.12.88zM9 3.76a1 1 0 0 0-.71.29L4.05 8.29a1 1 0 0 0-.29.71v6a1 1 0 0 0 .29.71L8.29 20a1 1 0 0 0 .71.29h6a1 1 0 0 0 .71-.29L20 15.71a1 1 0 0 0 .29-.71V9a1 1 0 0 0-.29-.71l-4.29-4.24a1 1 0 0 0-.71-.29z" fill="#5e72e4" data-original="#000000"></path><path d="M12 14a1 1 0 0 1-1-.8c0-.16-1-5-1-5.2a2 2 0 0 1 4 0c0 .16-1 5-1 5.2a1 1 0 0 1-1 .8zM11.29 17.71a1 1 0 0 1 0-1.42A1 1 0 0 1 13 17a1 1 0 0 1-1.71.71z" fill="#5e72e4" data-original="#000000"></path></g></g></svg><?php }
}
