<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/account_activation.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e80998661d3_38977850',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4ad4b42e5d91a1b5b18f55426a957d5532f2a917' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/account_activation.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e80998661d3_38977850 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g fill="#292d32" fill-rule="evenodd" clip-rule="evenodd"><path d="M3.885 5.237C3.205 5.868 2.75 6.893 2.75 8.5a.75.75 0 0 1-1.5 0c0-1.893.545-3.368 1.615-4.362C3.925 3.154 5.385 2.75 7 2.75h10c1.615 0 3.075.404 4.135 1.388 1.07.994 1.615 2.469 1.615 4.362v7c0 1.893-.545 3.369-1.615 4.362-1.06.984-2.52 1.388-4.135 1.388H7a.75.75 0 0 1 0-1.5h10c1.385 0 2.425-.346 3.115-.987.68-.632 1.135-1.656 1.135-3.263v-7c0-1.607-.455-2.632-1.135-3.263-.69-.64-1.73-.987-3.115-.987H7c-1.385 0-2.425.346-3.115.987z" fill="#5e72e4" data-original="#292d32"></path><path d="M17.586 8.532a.75.75 0 0 1-.118 1.054l-3.13 2.5c-1.304 1.038-3.382 1.038-4.685 0H9.65l-3.12-2.5a.75.75 0 1 1 .938-1.171l3.119 2.499c.757.602 2.058.601 2.815 0l3.129-2.5a.75.75 0 0 1 1.054.118zM1.25 16.5a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5H2a.75.75 0 0 1-.75-.75zM1.25 12.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 0 1.5H2a.75.75 0 0 1-.75-.75z" opacity=".4" fill="#5e72e4" data-original="#292d32"></path></g></g></svg><?php }
}
