<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:51:15
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/reserved.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8163c67988_87744586',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'df37cf72ae66c2b1d25704c859e7efb8a0f8e0b5' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/reserved.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8163c67988_87744586 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><g fill="#232323"><path d="M21 20.75H3a.75.75 0 0 1 0-1.5h18a.75.75 0 0 1 0 1.5zM21 18.25H3a1.75 1.75 0 0 1-1.616-2.423l.417-1A1.744 1.744 0 0 1 3.35 13.75 8.759 8.759 0 0 1 12 6.25a.75.75 0 0 1 0 1.5 7.254 7.254 0 0 0-7.226 6.796.75.75 0 0 1-.749.704h-.609a.25.25 0 0 0-.23.154l-.417 1A.25.25 0 0 0 3 16.75h18a.25.25 0 0 0 .23-.346l-.416-1a.25.25 0 0 0-.23-.154h-.61a.75.75 0 0 1-.748-.704 7.25 7.25 0 0 0-4.722-6.351.75.75 0 0 1 .52-1.407 8.75 8.75 0 0 1 5.627 6.963 1.745 1.745 0 0 1 1.548 1.076l.416 1A1.75 1.75 0 0 1 21 18.25zM14 4.75h-4a.75.75 0 0 1 0-1.5h4a.75.75 0 0 1 0 1.5z" fill="#5e72e4" data-original="#232323"></path><path d="M12 7.75a.75.75 0 0 1-.75-.75V4a.75.75 0 0 1 1.5 0v3a.75.75 0 0 1-.75.75z" fill="#5e72e4" data-original="#232323"></path></g><path fill="#7fbde7" d="M3 9.75a.75.75 0 0 1-.693-1.035 6.263 6.263 0 0 1 3.407-3.408.75.75 0 1 1 .572 1.386 4.77 4.77 0 0 0-2.593 2.592A.75.75 0 0 1 3 9.75zM21 9.75a.75.75 0 0 1-.693-.465 4.775 4.775 0 0 0-2.593-2.592.75.75 0 0 1 .572-1.386 6.267 6.267 0 0 1 3.407 3.408A.75.75 0 0 1 21 9.75z" data-original="#7fbde7" class=""></path></g></g></svg><?php }
}
