<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:38
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/market.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c529584d6_63455437',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '115b876b43f3c99d07f176448fa695420fd4ba7f' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/market.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c529584d6_63455437 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="m29.241 10.407-2.803-6.583a2.996 2.996 0 0 0-2.76-1.825H8.525a3.004 3.004 0 0 0-2.736 1.769l-2.968 6.594c-.809 1.405-.382 3.195.969 4.017.067.041.14.071.209.108v12.512c0 1.654 1.346 3 3 3H25c1.654 0 3-1.346 3-3V14.487c.082-.044.167-.081.246-.131 1.305-.812 1.743-2.572.995-3.949zM18 28v-5h4v5zm8-1c0 .551-.449 1-1 1h-1v-5c0-1.103-.897-2-2-2h-4c-1.103 0-2 .897-2 2v5H7c-.551 0-1-.449-1-1V15a4.24 4.24 0 0 0 3.094-1.334c1.094 1 2.559 1.503 4.026 1.327 1.305-.158 2.258-.811 2.879-1.416.622.604 1.575 1.257 2.879 1.416.194.023.388.035.582.035 1.265 0 2.495-.495 3.444-1.362A4.24 4.24 0 0 0 25.998 15v12zm1.188-14.341a2.246 2.246 0 0 1-3.265-1.044 1.001 1.001 0 0 0-.843-.612.985.985 0 0 0-.93.47c-.666 1.074-1.858 1.672-3.029 1.534-1.417-.172-2.18-1.383-2.263-1.521a.999.999 0 0 0-1.716 0c-.083.138-.845 1.349-2.263 1.521-1.175.139-2.364-.46-3.029-1.534a.981.981 0 0 0-.93-.47.999.999 0 0 0-.843.612 2.244 2.244 0 0 1-3.246 1.056c-.423-.257-.544-.867-.264-1.331a.896.896 0 0 0 .056-.106l2.99-6.645c.161-.358.519-.589.912-.589h15.152c.402 0 .763.239.92.608l2.823 6.631a.776.776 0 0 0 .052.104c.264.463.137 1.053-.285 1.316z" data-original="#0c474d"></path><path fill="#3cacb6" d="M12 19H9a1 1 0 0 1 0-2h3a1 1 0 0 1 0 2z" data-original="#3cacb6" class=""></path></g></svg><?php }
}
