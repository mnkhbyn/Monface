<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:49:56
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/noty_notifications.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e811430aca4_09562899',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd7ee9cb0439945eb5b2b2664eb3252227d548e2e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/noty_notifications.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e811430aca4_09562899 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 200 200" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#00a5ec"><path d="M159.72 80.55A40.28 40.28 0 1 1 200 40.28a40.32 40.32 0 0 1-40.28 40.27zm0-66.55A26.28 26.28 0 1 0 186 40.28 26.3 26.3 0 0 0 159.72 14z" fill="#5e72e4" data-original="#00a5ec" class=""></path><path d="M162.43 200H30a30.06 30.06 0 0 1-30-30V37.57a30.06 30.06 0 0 1 30-30h74.29a7 7 0 1 1 0 14H30a16 16 0 0 0-16 16V170a16 16 0 0 0 16 16h132.4a16 16 0 0 0 16-16V95.69a7 7 0 1 1 14 0V170a30.06 30.06 0 0 1-29.97 30z" fill="#5e72e4" data-original="#00a5ec" class=""></path></g></g></svg><?php }
}
