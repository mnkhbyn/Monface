<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:51:15
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/html.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8163d54b63_64119195',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55235a4aa1bf3f0945199fa4c1d50e627f05d35e' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/html.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8163d54b63_64119195 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M315.36 4.64A16.001 16.001 0 0 0 304 0H48C21.49 0 0 21.491 0 48v416c0 26.51 21.49 48 48 48h112v-32H48c-8.837 0-16-7.163-16-16V48c0-8.837 7.163-16 16-16h240v64c0 17.673 14.327 32 32 32h64v48h32v-64a15.997 15.997 0 0 0-4.64-11.36l-96-96z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M176 288h32v128h32V288h32v-32h-96zM128 320H96v-64H64v160h32v-64h32v64h32V256h-32zM406.08 257.28a16 16 0 0 0-17.44 3.52L352 297.44l-36.64-36.64c-6.223-6.274-16.353-6.316-22.627-.093A16 16 0 0 0 288 272v144h32V310.56l20.64 20.64c6.241 6.204 16.319 6.204 22.56 0l20.8-20.64V416h32V272a16 16 0 0 0-9.92-14.72zM464 384V256h-32v144c0 8.837 7.163 16 16 16h64v-32h-48z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
