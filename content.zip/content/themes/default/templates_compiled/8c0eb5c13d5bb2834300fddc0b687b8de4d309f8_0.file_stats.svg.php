<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/stats.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d68f463_01274834',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8c0eb5c13d5bb2834300fddc0b687b8de4d309f8' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/stats.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d68f463_01274834 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M12 21.75c-5.38 0-9.75-4.37-9.75-9.75S6.62 2.25 12 2.25c.41 0 .66.33.66.74s-.25.76-.66.76c-4.55 0-8.25 3.7-8.25 8.25s3.7 8.25 8.25 8.25 8.25-3.7 8.25-8.25c0-.41.35-.67.76-.67s.74.25.74.67c0 5.38-4.37 9.75-9.75 9.75z" data-original="#4254b6"></path><path fill="#80aef8" d="M20.94 12.75H13c-.96 0-1.75-.79-1.75-1.75V3.06c0-.5.21-.97.59-1.31.37-.33.88-.49 1.37-.44 4.94.55 8.92 4.54 9.48 9.48.06.5-.1 1-.44 1.37-.33.37-.81.59-1.31.59zm-7.93-9.94c-.08 0-.14.04-.17.07s-.09.09-.09.19v7.94c0 .14.11.25.25.25h7.94c.1 0 .16-.05.19-.09.03-.03.08-.1.07-.2-.48-4.25-3.9-7.68-8.15-8.15h-.03z" data-original="#80aef8" class=""></path></g></svg><?php }
}
