<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/user_online.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d61f807_53514653',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8557d18b14082e74d36e1e6b0f3031876d1e78ff' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/user_online.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d61f807_53514653 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M29.213 20.658h-.262V6.883a3.042 3.042 0 0 0-3.039-3.038H6.088a3.042 3.042 0 0 0-3.039 3.038v13.775h-.262a1.69 1.69 0 0 0-1.688 1.688v1.021a4.794 4.794 0 0 0 4.789 4.789h20.223a4.794 4.794 0 0 0 4.789-4.789v-1.021c0-.931-.756-1.688-1.687-1.688zM4.85 6.883a1.24 1.24 0 0 1 1.238-1.238h19.824a1.24 1.24 0 0 1 1.238 1.238v13.775H4.85zM29.1 23.367a2.992 2.992 0 0 1-2.988 2.989H5.889a2.992 2.992 0 0 1-2.988-2.989v-.909H29.1z" data-original="#6621ba"></path><path fill="#5e72e4" d="M18.938 15.582c.922-.816 1.516-1.995 1.516-3.321 0-2.456-1.998-4.453-4.454-4.453s-4.454 1.998-4.454 4.453c0 1.326.594 2.504 1.516 3.321-.763.381-1.39.905-1.781 1.541a.9.9 0 1 0 1.533.943c.413-.672 1.559-1.351 3.186-1.351s2.772.678 3.186 1.351a.9.9 0 0 0 1.534-.942c-.392-.637-1.019-1.161-1.782-1.542zm-5.591-3.32c0-1.463 1.19-2.653 2.653-2.653s2.653 1.19 2.653 2.653-1.19 2.653-2.653 2.653-2.653-1.19-2.653-2.653z" data-original="#f98a17" class=""></path></g></svg><?php }
}
