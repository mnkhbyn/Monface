<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:29
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/watermark.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8135a87d01_66111460',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '857695ca516fb62eb529d9e04243bcb91464d120' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/watermark.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8135a87d01_66111460 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#7fbde7" d="M18 22.75H6a.75.75 0 0 1 0-1.5h12a.75.75 0 0 1 0 1.5z" data-original="#7fbde7"></path><path fill="#5e72e4" d="M18 19.75H6a1.25 1.25 0 0 1-1.25-1.25V16a2.75 2.75 0 0 1 2.75-2.75h1.69l-.69-8.2a3.55 3.55 0 0 1 1-2.72 3.6 3.6 0 0 1 2.68-1.08 3.42 3.42 0 0 1 2.42 1.17 3.75 3.75 0 0 1 .92 2.79l-.67 8h1.65A2.75 2.75 0 0 1 19.25 16v2.5A1.25 1.25 0 0 1 18 19.75zm-11.75-1.5h11.5V16a1.25 1.25 0 0 0-1.25-1.25h-2a1.24 1.24 0 0 1-1.2-1.35l.7-8.31a2.25 2.25 0 0 0-.56-1.68 1.91 1.91 0 0 0-1.35-.66 2 2 0 0 0-1.53.62A2 2 0 0 0 10 4.93l.7 8.47a1.24 1.24 0 0 1-1.24 1.35h-2A1.25 1.25 0 0 0 6.25 16z" data-original="#232323" class=""></path></g></g></svg><?php }
}
