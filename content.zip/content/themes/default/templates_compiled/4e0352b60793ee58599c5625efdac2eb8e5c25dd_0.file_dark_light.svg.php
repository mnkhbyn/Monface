<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:54
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/dark_light.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c620d17c1_56212990',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e0352b60793ee58599c5625efdac2eb8e5c25dd' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/dark_light.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c620d17c1_56212990 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><g fill="#6ca4ff"><path d="M13 19a6.79 6.79 0 0 1-2.93-.65l-1.94-.92 1.95-.89a5 5 0 0 0 0-9.08l-1.95-.89 1.94-.92A6.79 6.79 0 0 1 13 5a7 7 0 0 1 0 14zm-.1-2a5 5 0 1 0 0-10 7 7 0 0 1 0 10z" fill="#5e72e4" data-original="#6ca4ff"></path><rect width="4" height="2" x="19" y="11" rx="1" fill="#5e72e4" data-original="#6ca4ff"></rect><rect width="4" height="2" x="16" y="5" rx="1" transform="rotate(-45 18.006 6.005)" fill="#5e72e4" data-original="#6ca4ff"></rect><rect width="2" height="4" x="12" y="2" rx="1" fill="#5e72e4" data-original="#6ca4ff"></rect><rect width="2" height="4" x="12" y="18" rx="1" fill="#5e72e4" data-original="#6ca4ff"></rect><rect width="2" height="4" x="17" y="16" rx="1" transform="rotate(-45 17.996 18.01)" fill="#5e72e4" data-original="#6ca4ff"></rect></g><path fill="#5e72e4" d="M8 19A7 7 0 0 1 8 5a6.79 6.79 0 0 1 2.93.65 7 7 0 0 1 0 12.71A6.85 6.85 0 0 1 8 19zM8 7a5 5 0 0 0 0 10 4.78 4.78 0 0 0 2.07-.45 5 5 0 0 0 0-9.09A4.72 4.72 0 0 0 8 7z" data-original="#0554f1" class=""></path><path fill="#5e72e4" d="M7 6h2v12H7z" data-original="#0554f1" class=""></path><path fill="#5e72e4" d="M10.5 6.55A5.82 5.82 0 0 0 8 6v12a5.82 5.82 0 0 0 2.5-.55 6 6 0 0 0 0-10.9z" data-original="#0554f1" class=""></path></g></g></svg><?php }
}
