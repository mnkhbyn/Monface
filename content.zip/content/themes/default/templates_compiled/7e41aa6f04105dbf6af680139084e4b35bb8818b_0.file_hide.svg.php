<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:29:58
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/hide.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7c6625db27_78794829',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7e41aa6f04105dbf6af680139084e4b35bb8818b' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/hide.svg',
      1 => 1685357399,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7c6625db27_78794829 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
echo '<?'; ?>
xml version="1.0"<?php echo '?>'; ?>

<svg xmlns="http://www.w3.org/2000/svg" id="Layer_2" data-name="Layer 2" viewBox="0 0 32 32" width="512" height="512"><path d="M16,25a12.67,12.67,0,0,1-2.293-.214,1,1,0,0,1-.842-.986,1.016,1.016,0,0,1,1.188-.984A10.666,10.666,0,0,0,16,23c5.924,0,11.069-5.187,12.687-7a26.915,26.915,0,0,0-3.54-3.308,1,1,0,0,1,1.225-1.582,27.326,27.326,0,0,1,4.416,4.275,1,1,0,0,1,0,1.233C30.519,16.959,24.124,25,16,25Z"/><path d="M26.707,5.293a1,1,0,0,0-1.414,0l-3.18,3.18a15.513,15.513,0,0,0-3.79-1.256A12.6,12.6,0,0,0,16,7C7.876,7,1.481,15.041,1.213,15.383a1,1,0,0,0,0,1.233,27.282,27.282,0,0,0,4.412,4.271,23.614,23.614,0,0,0,2.414,1.661L5.293,25.293a1,1,0,1,0,1.414,1.414l20-20A1,1,0,0,0,26.707,5.293ZM6.853,19.309A26.915,26.915,0,0,1,3.313,16C4.931,14.188,10.076,9,16,9a10.632,10.632,0,0,1,1.961.184,12.974,12.974,0,0,1,2.638.8l-1.842,1.842a5,5,0,0,0-6.928,6.928L9.5,21.087A20.988,20.988,0,0,1,6.853,19.309ZM13.3,17.284A2.972,2.972,0,0,1,13,16a3.01,3.01,0,0,1,.872-2.118,3.079,3.079,0,0,1,3.4-.57Z"/></svg>
<?php }
}
