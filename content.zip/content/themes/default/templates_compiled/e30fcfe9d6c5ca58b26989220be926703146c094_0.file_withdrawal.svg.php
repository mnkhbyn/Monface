<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:50:50
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/withdrawal.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e814a090504_13629173',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e30fcfe9d6c5ca58b26989220be926703146c094' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/withdrawal.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e814a090504_13629173 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M15.16 21.75H8.84c-.84 0-1.65-.35-2.21-.96-.55-.6-.82-1.37-.76-2.17l.77-9.69c.12-1.5 1.42-2.68 2.97-2.68h4.78c1.54 0 2.85 1.18 2.97 2.68l.77 9.69c.06.8-.21 1.57-.76 2.17-.56.61-1.37.96-2.21.96zm-5.55-14c-.77 0-1.41.57-1.47 1.3l-.77 9.69c-.03.38.1.75.36 1.03.28.3.68.48 1.11.48h6.32c.42 0 .83-.17 1.11-.48.26-.29.39-.65.36-1.03l-.77-9.69c-.06-.73-.7-1.3-1.47-1.3z" data-original="#4254b6" class=""></path><g fill="#80aef8"><path d="M12 16.37c-1.3 0-2.37-1.06-2.37-2.37s1.06-2.37 2.37-2.37 2.37 1.06 2.37 2.37-1.06 2.37-2.37 2.37zm0-3.23a.87.87 0 1 0 .001 1.741A.87.87 0 0 0 12 13.14zM13.08 19.6h-2.15c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h2.15c.41 0 .75.34.75.75s-.34.75-.75.75zM13.08 9.9h-2.15c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h2.15c.41 0 .75.34.75.75s-.34.75-.75.75z" fill="#80aef8" data-original="#80aef8"></path></g><path fill="#5e72e4" d="M4.04 11.24c-.12 0-.25-.03-.37-.1A4.755 4.755 0 0 1 1.24 7 4.77 4.77 0 0 1 6 2.25h12c2.62 0 4.75 2.13 4.75 4.75 0 1.69-.91 3.26-2.37 4.11-.36.21-.82.08-1.02-.27a.738.738 0 0 1 .27-1.02c1-.58 1.62-1.66 1.62-2.81 0-1.79-1.46-3.25-3.25-3.25H6c-1.79 0-3.25 1.46-3.25 3.25 0 1.17.64 2.26 1.66 2.84.36.2.49.66.29 1.02a.74.74 0 0 1-.66.38z" data-original="#4254b6" class=""></path></g></svg><?php }
}
