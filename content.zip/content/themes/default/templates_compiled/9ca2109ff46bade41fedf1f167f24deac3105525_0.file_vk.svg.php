<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:47:53
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/vk.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8099c1b301_86850246',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9ca2109ff46bade41fedf1f167f24deac3105525' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/vk.svg',
      1 => 1710769599,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8099c1b301_86850246 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" width="2500" height="2500" viewBox="0 0 192 192"><g fill="none" fill-rule="evenodd"><path fill="#2787f5" d="M66.56 0h58.88C179.2 0 192 12.8 192 66.56v58.88c0 53.76-12.8 66.56-66.56 66.56H66.56C12.8 192 0 179.2 0 125.44V66.56C0 12.8 12.8 0 66.56 0z"/><path fill="#FFF" d="M157.234 66.146c.89-2.966 0-5.146-4.234-5.146h-14c-3.56 0-5.2 1.883-6.09 3.96 0 0-7.12 17.353-17.206 28.625-3.263 3.263-4.746 4.301-6.526 4.301-.89 0-2.178-1.038-2.178-4.004V66.146c0-3.56-1.033-5.146-4-5.146H81c-2.224 0-3.562 1.652-3.562 3.218 0 3.375 5.042 4.153 5.562 13.645V98.48c0 4.52-.816 5.34-2.596 5.34-4.746 0-16.29-17.432-23.138-37.377C55.924 62.566 54.578 61 51 61H37c-4 0-4.8 1.883-4.8 3.96 0 3.708 4.747 22.1 22.1 46.424C65.869 127.995 82.168 137 97 137c8.9 0 10-2 10-5.445V119c0-4 .843-4.798 3.661-4.798 2.077 0 5.636 1.038 13.943 9.047C134.096 132.742 135.66 137 141 137h14c4 0 6-2 4.846-5.947-1.262-3.934-5.794-9.64-11.808-16.406-3.263-3.857-8.158-8.01-9.64-10.086-2.077-2.67-1.484-3.857 0-6.23 0 0 17.056-24.027 18.836-32.185z"/></g></svg><?php }
}
