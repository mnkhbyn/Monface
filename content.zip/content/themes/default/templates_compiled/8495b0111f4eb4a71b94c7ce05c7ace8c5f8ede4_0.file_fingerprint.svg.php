<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:51:15
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/fingerprint.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e8163be96b7_63522439',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8495b0111f4eb4a71b94c7ce05c7ace8c5f8ede4' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/fingerprint.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e8163be96b7_63522439 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#6621ba"><path d="M13.017 8.498a.9.9 0 1 0 .749 1.637 5.385 5.385 0 0 1 7.612 4.893.9.9 0 0 0 1.8 0c0-3.958-3.22-7.178-7.178-7.178a7.12 7.12 0 0 0-2.983.648zM9.951 11.162a7.152 7.152 0 0 0-1.129 3.866v5.231a.9.9 0 0 0 1.8 0v-5.231c0-1.031.292-2.032.845-2.895a.9.9 0 1 0-1.516-.971z" fill="#5e72e4" data-original="#6621ba"></path><path d="M20.04 17.47v-2.44c0-1.079-.42-2.093-1.184-2.856A4.01 4.01 0 0 0 16 10.99a4.044 4.044 0 0 0-4.04 4.04v7.28a.9.9 0 0 0 1.8 0v-7.28A2.243 2.243 0 0 1 16 12.79c.598 0 1.16.233 1.584.656.423.423.656.986.656 1.583v2.44a.9.9 0 0 0 1.8.001z" fill="#5e72e4" data-original="#6621ba"></path><path d="M15.1 23.25a.9.9 0 0 0 1.8 0v-5.074a.9.9 0 0 0-1.8 0zM16 16.347a.9.9 0 0 0 .9-.9v-.419a.9.9 0 0 0-1.8 0v.419a.9.9 0 0 0 .9.9z" fill="#5e72e4" data-original="#6621ba"></path><path d="M17.07 29.053c-.357.028-.714.047-1.07.047-7.223 0-13.1-5.877-13.1-13.1S8.777 2.9 16 2.9 29.1 8.777 29.1 16c0 .356-.019.713-.047 1.07a.9.9 0 0 0 1.795.141c.031-.404.052-.808.052-1.211 0-8.216-6.684-14.9-14.9-14.9S1.1 7.784 1.1 16 7.784 30.9 16 30.9c.403 0 .807-.021 1.21-.052.496-.039.866-.472.827-.968s-.472-.853-.967-.827z" fill="#5e72e4" data-original="#6621ba"></path></g><g fill="#f98a17"><path d="M24.772 18.645c-3.379 0-6.127 2.749-6.127 6.127s2.749 6.127 6.127 6.127 6.127-2.749 6.127-6.127-2.748-6.127-6.127-6.127zm0 10.455c-2.386 0-4.328-1.941-4.328-4.328s1.941-4.328 4.328-4.328 4.328 1.941 4.328 4.328-1.941 4.328-4.328 4.328z" fill="#5e72e4" data-original="#f98a17" class=""></path><path d="m25.985 23.182-1.842 1.484-.44-.562a.9.9 0 0 0-1.417 1.111l1.003 1.279a.902.902 0 0 0 1.272.146l2.552-2.056a.9.9 0 0 0-1.128-1.402z" fill="#5e72e4" data-original="#f98a17" class=""></path></g></g></svg><?php }
}
