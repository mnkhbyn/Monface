<?php
/* Smarty version 5.4.1, created on 2024-10-15 14:39:09
  from 'file:D:\xampp\htdocs\sngine\Script\content\themes\default\templates\../images/svg/language.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_670e7e8d7e3902_25793215',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5ccae8bba395d3f50dbc3516d99adcde55a0037f' => 
    array (
      0 => 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\templates\\../images/svg/language.svg',
      1 => 1684863814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_670e7e8d7e3902_25793215 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'D:\\xampp\\htdocs\\sngine\\Script\\content\\themes\\default\\images\\svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#000"><path d="M14.79 19.42c-.11 0-.23-.03-.33-.08a.763.763 0 0 1-.34-1.01l2.14-4.27c.13-.25.39-.41.67-.41s.54.16.67.42l2.14 4.27c.19.37.04.82-.34 1.01-.37.19-.82.04-1.01-.34l-1.46-2.93-1.46 2.93a.78.78 0 0 1-.68.41z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M18.68 18.66h-3.52c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h3.52a.749.749 0 1 1 0 1.5z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M16.92 22.75a5.83 5.83 0 1 1 0-11.66 5.83 5.83 0 0 1 0 11.66zm0-10.15c-2.39 0-4.33 1.94-4.33 4.33s1.94 4.33 4.33 4.33c2.38 0 4.33-1.94 4.33-4.33s-1.94-4.33-4.33-4.33zM4.86 12.7c-1.11 0-1.99-.31-2.61-.91-.66-.64-1-1.61-1-2.86V5.01c0-2.43 1.34-3.77 3.77-3.77h3.92c1.25 0 2.21.33 2.86 1 .63.65.94 1.59.91 2.79v3.9c.03 1.22-.28 2.18-.93 2.83s-1.61.95-2.85.93h-3.9c-.07.01-.12.01-.17.01zm.16-9.95c-1.61 0-2.27.66-2.27 2.27v3.92c0 .83.18 1.43.54 1.78.35.34.91.49 1.7.48h3.94c.84.02 1.42-.15 1.77-.5s.51-.94.49-1.75V5.01c.02-.8-.14-1.37-.48-1.72-.35-.36-.95-.54-1.78-.54z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M9 6.6H4.94c-.41 0-.75-.34-.75-.75s.34-.75.75-.75H9a.749.749 0 1 1 0 1.5z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M6.98 6.6c-.41 0-.75-.34-.75-.75v-.68c0-.41.34-.75.75-.75s.75.34.75.75v.68c0 .41-.34.75-.75.75z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M4.94 9.76c-.41 0-.75-.34-.75-.75s.34-.75.75-.75c1.27 0 2.3-1.08 2.3-2.42 0-.41.34-.75.75-.75s.75.34.75.75c0 2.16-1.7 3.92-3.8 3.92z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M9.01 9.76c-.93 0-1.82-.47-2.45-1.3a.75.75 0 0 1 1.2-.9c.34.46.79.71 1.25.71.41 0 .75.34.75.75s-.34.74-.75.74z" fill="#5e72e4" data-original="#000000" class=""></path></g><path fill="#aaaaaa" d="M9 22.75c-4.27 0-7.75-3.48-7.75-7.75 0-.41.34-.75.75-.75s.75.34.75.75c0 2.96 2.06 5.44 4.83 6.09l-.27-.45a.751.751 0 1 1 1.29-.77l1.05 1.75c.14.23.14.52.01.75-.14.23-.39.38-.66.38zM22 9.75c-.41 0-.75-.34-.75-.75 0-2.96-2.06-5.44-4.83-6.09l.27.45a.751.751 0 1 1-1.29.77l-1.05-1.75a.745.745 0 0 1-.01-.75c.13-.24.38-.38.65-.38 4.27 0 7.75 3.48 7.75 7.75a.74.74 0 0 1-.74.75z" data-original="#aaaaaa" class=""></path></g></svg><?php }
}
